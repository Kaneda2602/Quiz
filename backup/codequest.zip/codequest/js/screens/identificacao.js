// Identificação: aparece só enquanto o perfil não tem nome (primeiro login).
App.register("identificacao", {
  init() {
    this.form = document.getElementById("nome-form");
    this.input = document.getElementById("nome-input");
    this.msg = document.getElementById("nome-msg");
    this.btn = this.form.querySelector(".btn-jogar");

    this.form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.submit();
    });
  },

  enter() {
    this.input.value = "";
    this.setMsg("");
    setTimeout(() => this.input.focus(), 0);
  },

  setMsg(text) {
    this.msg.textContent = text;
    this.msg.classList.toggle("erro", Boolean(text));
  },

  async submit() {
    const nome = this.input.value.trim();
    if (nome.length < 2 || nome.length > 40) {
      return this.setMsg("O nome precisa ter entre 2 e 40 caracteres.");
    }

    this.btn.disabled = true;
    try {
      const rows = await App.withLoading(() => App.rpc("set_my_name", { p_name: nome }));
      App.state.profile = rows[0];
      await App.go("temas");
    } catch (err) {
      this.setMsg(App.errorMessage(err));
    } finally {
      this.btn.disabled = false;
    }
  },
});
