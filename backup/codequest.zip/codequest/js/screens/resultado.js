// Resultado da tentativa encerrada.
App.register("resultado", {
  init() {
    document.getElementById("resultado-voltar").addEventListener("click", () => App.go("temas"));
    document.getElementById("resultado-avancar").addEventListener("click", () =>
      App.go("ranking", {
        quizVersionId: App.state.attempt.quiz_version_id,
        tema: App.state.quiz.title,
        voltar: "resultado",
      }),
    );
  },

  enter() {
    const a = App.state.attempt;
    const aproveitamento = Math.round((a.correct_count / a.total_questions) * 100);

    document.getElementById("resultado-acertos").textContent =
      `${a.correct_count}/${a.total_questions}`;
    // só a 1ª partida do jogador nesta versão do quiz entra no ranking
    document.getElementById("resultado-pontos").textContent =
      `${a.score}/${a.max_score} pts` + (a.is_ranked ? "" : " · treino");
    document.getElementById("resultado-aproveitamento").textContent = `${aproveitamento}%`;
    document.getElementById("resultado-tempo").textContent = App.formatDuration(
      new Date(a.finished_at) - new Date(a.started_at),
    );
  },
});
