// Ranking de uma versão de quiz, com pódio para o top 3.
// Abre a partir do resultado (quiz recém-jogado) ou da tela de temas (tema selecionado).
App.register("ranking", {
  voltar: "temas",

  init() {
    document.getElementById("ranking-voltar").addEventListener("click", () => App.go(this.voltar));
    document.getElementById("ranking-avancar").addEventListener("click", () => App.go("temas"));
  },

  async enter({ quizVersionId, tema, voltar }) {
    this.voltar = voltar;
    document.getElementById("ranking-tema").textContent = tema ?? "";

    const lista = document.getElementById("ranking-lista");
    let rows = [];
    try {
      rows = await App.withLoading(() =>
        App.rpc("get_leaderboard", { p_quiz_version_id: quizVersionId, p_limit: 100 }),
      );
    } catch (err) {
      App.showError(err);
    }

    if (rows.length === 0) {
      const vazio = document.createElement("li");
      vazio.className = "ranking-vazio";
      vazio.textContent = "Ninguém no ranking ainda.";
      lista.replaceChildren(vazio);
    } else {
      lista.replaceChildren(...rows.map((r) => this.item(r)));
    }

    [1, 2, 3].forEach((pos) => {
      document.getElementById(`podio-${pos}`).textContent = rows[pos - 1]?.name ?? "";
    });
    document.querySelector(".medalha.ouro").hidden = rows.length < 1;
    document.querySelector(".medalha.prata").hidden = rows.length < 2;
    document.querySelector(".medalha.bronze").hidden = rows.length < 3;
  },

  item(r) {
    const li = document.createElement("li");
    li.className = "ranking-item";
    li.classList.toggle("eu", r.user_id === App.state.profile.id);

    const pos = document.createElement("span");
    pos.className = "pos";
    pos.textContent = `${r.rank_position}º`;
    const nome = document.createElement("span");
    nome.className = "nome";
    nome.textContent = r.name;
    const pts = document.createElement("span");
    pts.className = "pts";
    pts.textContent = `${r.score} pts`;

    li.append(pos, nome, pts);
    return li;
  },
});
