// Login e cadastro na mesma tela, alternando o modo pelo link abaixo do botão.
App.register("login", {
  mode: "entrar",

  init() {
    this.form = document.getElementById("login-form");
    this.msg = document.getElementById("login-msg");
    this.submitBtn = document.getElementById("login-submit");

    document.getElementById("login-toggle").addEventListener("click", () => {
      this.setMode(this.mode === "entrar" ? "cadastrar" : "entrar");
    });
    this.form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.submit();
    });
  },

  enter() {
    this.form.reset();
    this.setMode("entrar");
  },

  setMode(mode, msg = "") {
    this.mode = mode;
    const cadastro = mode === "cadastrar";
    document.getElementById("login-heading").textContent = cadastro ? "CRIAR CONTA" : "ENTRAR";
    this.submitBtn.querySelector("span").textContent = cadastro ? "CRIAR" : "ENTRAR";
    document.getElementById("login-toggle").textContent = cadastro
      ? "Já tem conta? Entrar"
      : "Não tem conta? Criar conta";
    this.form.password.autocomplete = cadastro ? "new-password" : "current-password";
    this.setMsg(msg);
  },

  setMsg(text, erro = false) {
    this.msg.textContent = text;
    this.msg.classList.toggle("erro", erro);
  },

  async submit() {
    const email = this.form.email.value.trim();
    const password = this.form.password.value;

    if (!email || !this.form.email.checkValidity()) {
      return this.setMsg("Digite um email válido.", true);
    }
    if (password.length < 6) {
      return this.setMsg("A senha precisa ter pelo menos 6 caracteres.", true);
    }

    this.submitBtn.disabled = true;
    this.setMsg("");
    try {
      if (this.mode === "cadastrar") {
        const { data, error } = await App.withLoading(() => sb.auth.signUp({ email, password }));
        if (error) throw error;
        // Com confirmação de email ligada no projeto, o cadastro não devolve sessão.
        if (!data.session) {
          this.form.password.value = "";
          return this.setMode("entrar", "Conta criada! Confirme pelo link no seu email e depois entre.");
        }
      } else {
        const { error } = await App.withLoading(() =>
          sb.auth.signInWithPassword({ email, password }),
        );
        if (error) throw error;
      }
      await App.routeAfterLogin();
    } catch (err) {
      this.setMsg(App.errorMessage(err), true);
    } finally {
      this.submitBtn.disabled = false;
    }
  },
});
