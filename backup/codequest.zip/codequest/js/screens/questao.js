// Questão: mostra a pergunta, envia a alternativa e exibe o popup de correta/incorreta.
App.register("questao", {
  init() {
    this.lista = document.getElementById("alternativas");
    this.feedback = document.getElementById("feedback");
    this.avancar = document.getElementById("questao-avancar");

    this.avancar.addEventListener("click", () => this.next());
    document.getElementById("feedback-fechar").addEventListener("click", () => {
      this.feedback.hidden = true;
    });
  },

  enter({ index }) {
    App.state.index = index;
    this.render();
  },

  get question() {
    return App.state.questions[App.state.index];
  },

  render() {
    const { questions, index } = App.state;
    const q = this.question;

    document.getElementById("questao-contador").textContent =
      `Pergunta ${index + 1} de ${questions.length}`;
    document.getElementById("questao-progresso").style.backgroundImage =
      `url("assets/sprites/progresso-${index + 1}.png")`;

    const enunciado = document.getElementById("questao-enunciado");
    enunciado.textContent = q.statement;
    enunciado.classList.toggle("longo", q.statement.length > 90);

    this.feedback.hidden = true;
    this.avancar.disabled = true;
    this.avancar.querySelector("span").textContent =
      index === questions.length - 1 ? "FINALIZAR" : "AVANÇAR";
    this.answering = false;

    this.lista.replaceChildren(
      ...q.options.map((opt, i) => {
        const li = document.createElement("li");
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "alternativa";
        btn.dataset.optionId = opt.id;

        const letra = document.createElement("span");
        letra.className = `letra sprite letra-${i + 1}`;
        letra.textContent = String.fromCharCode(65 + i);
        if (i < 4) {
          App.spriteExists(`letra-${letra.textContent.toLowerCase()}.png`).then((ok) => {
            letra.classList.toggle("tem-sprite", ok);
          });
        }

        const texto = document.createElement("span");
        texto.textContent = opt.body;

        btn.append(letra, texto);
        btn.addEventListener("click", () => this.answer(opt.id));
        li.append(btn);
        return li;
      }),
    );
  },

  async answer(optionId) {
    if (this.answering) return;
    this.answering = true;
    const botoes = [...this.lista.querySelectorAll(".alternativa")];
    botoes.forEach((b) => (b.disabled = true));

    try {
      const rows = await App.withLoading(() =>
        App.rpc("submit_answer", {
          p_attempt_id: App.state.attempt.id,
          p_question_id: this.question.question_id,
          p_option_id: optionId,
        }),
      );
      const result = rows[0];
      Object.assign(this.question, { selected_option_id: optionId, is_correct: result.is_correct });

      botoes.forEach((b) => {
        const id = b.dataset.optionId;
        if (id === result.correct_option_id) b.classList.add("correta");
        else if (id === optionId) b.classList.add("errada");
        else b.classList.add("apagada");
      });
      this.showFeedback(result);
      this.avancar.disabled = false;
    } catch (err) {
      App.showError(err);
      botoes.forEach((b) => (b.disabled = false));
      this.answering = false;
    }
  },

  showFeedback(result) {
    this.feedback.classList.toggle("acertou", result.is_correct);
    this.feedback.classList.toggle("errou", !result.is_correct);
    document.getElementById("feedback-titulo").textContent = result.is_correct
      ? "Resposta Correta!"
      : "Resposta Incorreta!";
    document.getElementById("feedback-pontos").textContent = result.is_correct
      ? `+${result.points_awarded} pontos`
      : "A alternativa certa está em verde.";
    document.getElementById("feedback-texto").textContent =
      result.explanation || "Sem explicação cadastrada para esta pergunta.";

    const fonte = document.getElementById("feedback-fonte");
    fonte.hidden = !result.source_url;
    if (result.source_url) fonte.href = result.source_url;

    this.feedback.hidden = false;
  },

  async next() {
    const { questions, index } = App.state;
    const proxima = questions.findIndex((q, i) => i > index && !q.selected_option_id);
    if (proxima === -1) {
      await this.finish();
    } else {
      App.state.index = proxima;
      this.render();
    }
  },

  async finish() {
    this.avancar.disabled = true;
    try {
      const attempt = await App.withLoading(() =>
        App.rpc("finish_attempt", { p_attempt_id: App.state.attempt.id }),
      );
      App.state.attempt = attempt;
      await App.go("resultado");
    } catch (err) {
      App.showError(err);
      this.avancar.disabled = false;
    }
  },
});
