// Temas: os 6 do Figma. Só ficam jogáveis os que têm quiz publicado no catálogo.
const TEMAS = [
  { slug: "cybersecurity",       nome: "Cybersegurança",          sprite: "tema-cybersecurity.png" },
  { slug: "frontend",            nome: "Front-End",               sprite: "tema-frontend.png" },
  { slug: "backend",             nome: "Back-End",                sprite: "tema-backend.png" },
  { slug: "ia",                  nome: "I.A",                     sprite: "tema-ia.png" },
  { slug: "historia-computacao", nome: "História da Computação",  sprite: "tema-historia.png" },
  { slug: "aleatorio",           nome: "Aleatório",               sprite: "tema-aleatorio.png" },
];

App.register("temas", {
  selected: null,

  init() {
    this.grid = document.getElementById("temas-grid");
    this.avancar = document.getElementById("temas-avancar");
    this.rankingBtn = document.getElementById("temas-ranking");

    this.avancar.addEventListener("click", () => this.start());
    this.rankingBtn.addEventListener("click", () => {
      App.go("ranking", {
        quizVersionId: this.selected.published_version_id,
        tema: this.selected.title,
        voltar: "temas",
      });
    });
    document.getElementById("temas-sair").addEventListener("click", () => sb.auth.signOut());
  },

  async enter() {
    document.getElementById("temas-ola").textContent = `Olá, ${App.state.profile.name}!`;
    this.selected = null;
    this.avancar.disabled = true;
    this.rankingBtn.disabled = true;

    try {
      const { data, error } = await App.withLoading(() =>
        sb.from("quiz_catalog").select("*").order("title"),
      );
      if (error) throw error;
      App.state.catalog = data;
    } catch (err) {
      App.state.catalog = [];
      App.showError(err);
    }
    this.render();
  },

  render() {
    this.grid.replaceChildren(
      ...TEMAS.map((tema) => {
        const quiz = App.state.catalog.find((q) => q.category_slug === tema.slug);

        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "tema";
        btn.disabled = !quiz;
        btn.setAttribute("aria-pressed", "false");

        const nome = document.createElement("span");
        nome.className = "tema-nome";
        nome.textContent = tema.nome;

        const card = document.createElement("span");
        card.className = "tema-card sprite";
        const icone = document.createElement("span");
        icone.className = "tema-icone sprite";
        icone.style.backgroundImage = `url("assets/sprites/${tema.sprite}")`;
        card.append(icone);

        if (quiz) {
          btn.addEventListener("click", () => this.select(btn, quiz));
          btn.addEventListener("dblclick", () => this.start());
        } else {
          const badge = document.createElement("span");
          badge.className = "tema-bloqueado";
          badge.textContent = "EM BREVE";
          card.append(badge);
        }

        btn.append(nome, card);
        return btn;
      }),
    );
  },

  select(btn, quiz) {
    this.grid.querySelectorAll(".tema").forEach((el) => el.setAttribute("aria-pressed", "false"));
    btn.setAttribute("aria-pressed", "true");
    this.selected = quiz;
    this.avancar.disabled = false;
    this.rankingBtn.disabled = false;
  },

  // Inicia (ou retoma) a tentativa e pula direto para a primeira pergunta sem resposta.
  async start() {
    if (!this.selected || this.avancar.dataset.busy) return;
    this.avancar.dataset.busy = "1";
    this.avancar.disabled = true;

    try {
      await App.withLoading(async () => {
        const attempt = await App.rpc("start_attempt", { p_quiz_id: this.selected.quiz_id });
        const questions = await App.rpc("get_attempt_questions", { p_attempt_id: attempt.id });
        Object.assign(App.state, { quiz: this.selected, attempt, questions });
      });

      const next = App.state.questions.findIndex((q) => !q.selected_option_id);
      if (next === -1) {
        // todas respondidas (partida interrompida antes do fim): só falta encerrar
        await App.screens.questao.finish();
      } else {
        await App.go("questao", { index: next });
        if (next > 0) App.toast(`Continuando sua partida da pergunta ${next + 1}.`);
      }
    } catch (err) {
      App.showError(err);
      this.avancar.disabled = false;
    } finally {
      delete this.avancar.dataset.busy;
    }
  },
});
