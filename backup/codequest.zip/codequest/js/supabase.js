// Cliente do Supabase (supabase-js carregado via CDN em index.html).
// A chave anon é pública por design: quem protege os dados são o RLS e os grants das RPCs.
const SUPABASE_URL = "https://brnhhbxcyaytbleuufud.supabase.co";
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJybmhoYnhjeWF5dGJsZXV1ZnVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE3OTI3MjAsImV4cCI6MjEwNzM2ODcyMH0.ZrJ_rFZuY_mnUHcOTHt5k9LqETJtLkGsXgffJroZYdU";

const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
