// Núcleo do jogo: estado, troca de telas, chamadas ao Supabase e feedback visual.
const App = {
  state: {
    profile: null,     // { id, name, email }
    catalog: [],       // linhas de quiz_catalog
    quiz: null,        // linha de quiz_catalog escolhida
    attempt: null,     // linha de quiz_attempts
    questions: [],     // retorno de get_attempt_questions
    index: 0,          // pergunta atual
  },

  screens: {},
  current: null,

  register(name, screen) {
    this.screens[name] = screen;
    screen.init?.();
  },

  async go(name, params) {
    document.querySelectorAll(".screen").forEach((el) => el.classList.remove("active"));
    this.hideToast();
    this.current = name;
    await this.screens[name].enter?.(params);
    if (this.current === name) {
      document.getElementById(`screen-${name}`).classList.add("active");
    }
  },

  // ---------------------------------------------------------------------------
  // Supabase
  // ---------------------------------------------------------------------------

  async rpc(fn, args) {
    const { data, error } = await sb.rpc(fn, args);
    if (error) throw error;
    return data;
  },

  async loadProfile() {
    const rows = await this.rpc("get_my_profile");
    this.state.profile = rows[0] ?? null;
    return this.state.profile;
  },

  // Depois do login: identificação só se o perfil ainda não tem nome.
  async routeAfterLogin() {
    const profile = await this.withLoading(() => this.loadProfile());
    await this.go(profile?.name ? "temas" : "identificacao");
  },

  errorMessage(err) {
    const msg = err?.message ?? String(err);
    const traducoes = {
      "Invalid login credentials": "Email ou senha incorretos.",
      "User already registered": "Este email já tem uma conta. Entre com sua senha.",
      "Email not confirmed": "Confirme seu email pelo link que enviamos antes de entrar.",
      "Failed to fetch": "Sem conexão com o servidor. Tente de novo.",
    };
    for (const [en, pt] of Object.entries(traducoes)) {
      if (msg.includes(en)) return pt;
    }
    if (/password/i.test(msg) && /6 characters/i.test(msg)) {
      return "A senha precisa ter pelo menos 6 caracteres.";
    }
    return msg;
  },

  // ---------------------------------------------------------------------------
  // Feedback visual
  // ---------------------------------------------------------------------------

  toast(msg, tipo = "info") {
    const el = document.getElementById("toast");
    el.textContent = msg;
    el.classList.toggle("erro", tipo === "erro");
    el.hidden = false;
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => this.hideToast(), 5000);
  },

  hideToast() {
    document.getElementById("toast").hidden = true;
  },

  showError(err) {
    console.error(err);
    this.toast(this.errorMessage(err), "erro");
  },

  async withLoading(fn) {
    const el = document.getElementById("loading");
    el.hidden = false;
    try {
      return await fn();
    } finally {
      el.hidden = true;
    }
  },

  // ---------------------------------------------------------------------------
  // Utilitários
  // ---------------------------------------------------------------------------

  // Sprites que podem não ter sido exportados ainda: só aplica a classe se o PNG carregar.
  _spriteCache: {},
  spriteExists(file) {
    if (!this._spriteCache[file]) {
      this._spriteCache[file] = new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve(true);
        img.onerror = () => resolve(false);
        img.src = `assets/sprites/${file}`;
      });
    }
    return this._spriteCache[file];
  },

  formatDuration(ms) {
    const total = Math.max(0, Math.round(ms / 1000));
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
  },

  // Escala o palco 1440×1024 para caber na janela mantendo a proporção do Figma.
  fitStage() {
    const scale = Math.min(window.innerWidth / 1440, window.innerHeight / 1024);
    document.documentElement.style.setProperty("--scale", scale);
  },
};
