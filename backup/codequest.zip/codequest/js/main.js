// Ponto de entrada: ajusta o palco e decide a primeira tela pela sessão salva.
(async function main() {
  App.fitStage();
  window.addEventListener("resize", () => App.fitStage());

  sb.auth.onAuthStateChange((event) => {
    if (event === "SIGNED_OUT") {
      App.state.profile = null;
      App.state.attempt = null;
      App.go("login");
    }
  });

  try {
    const { data } = await sb.auth.getSession();
    if (data.session) {
      await App.routeAfterLogin();
    } else {
      await App.go("login");
    }
  } catch (err) {
    await App.go("login");
    App.showError(err);
  }
})();
