-- =============================================================================
-- Quiz App — perguntas de múltipla escolha, com pontos e dificuldade
--
-- Substitui o modelo Certo/Errado:
--   * questions          -> ganha difficulty e points (definidos por pergunta)
--   * question_options   -> alternativas da pergunta (A, B, C, ... pela sort_order)
--   * question_solutions -> correct_answer boolean vira correct_option_id + source_url
--   * attempt_answers    -> selected_answer boolean vira selected_option_id + points_awarded
--   * quiz_attempts      -> ganha score / max_score; o ranking passa a ordenar por pontos
--
-- Feita com as tabelas vazias: as colunas novas são NOT NULL sem default.
-- =============================================================================


-- -----------------------------------------------------------------------------
-- Tipos
-- -----------------------------------------------------------------------------
create type public.question_difficulty as enum ('easy', 'medium', 'hard');


-- =============================================================================
-- CONTEÚDO
-- =============================================================================

alter table public.questions
  add column difficulty public.question_difficulty not null,
  add column points     integer not null check (points between 1 and 1000);

-- Alternativas. Ficam visíveis para o jogador; qual é a certa fica em question_solutions.
create table public.question_options (
  id          uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions (id) on delete cascade,
  sort_order  integer not null check (sort_order > 0),  -- 1 = A, 2 = B, ...
  body        text not null check (char_length(body) > 0),
  created_at  timestamptz not null default now(),
  unique (question_id, sort_order) deferrable initially immediate,
  unique (id, question_id)  -- alvo das FKs compostas em question_solutions e attempt_answers
);

create trigger question_options_guard
  before insert or update or delete on public.question_options
  for each row execute function private.guard_question_content();

-- Gabarito: a alternativa certa precisa ser da própria pergunta (FK composta).
-- NO ACTION (e não RESTRICT) para o cascade ao apagar a pergunta remover
-- alternativas e gabarito no mesmo comando.
alter table public.question_solutions
  drop column correct_answer,
  add column correct_option_id uuid not null,
  add column source_url text check (source_url ~ '^https?://'),
  add foreign key (correct_option_id, question_id)
    references public.question_options (id, question_id);

create index question_solutions_correct_option_idx
  on public.question_solutions (correct_option_id, question_id);


-- =============================================================================
-- TENTATIVAS E RESPOSTAS
-- =============================================================================

alter table public.quiz_attempts
  add column score     integer not null default 0,
  add column max_score integer not null check (max_score > 0),
  add check (score between 0 and max_score);

drop index public.quiz_attempts_leaderboard_idx;
create index quiz_attempts_leaderboard_idx
  on public.quiz_attempts (quiz_version_id, score desc, correct_count desc)
  where is_ranked and status <> 'in_progress';

alter table public.attempt_answers
  drop column selected_answer,
  add column selected_option_id uuid not null,
  add column points_awarded     integer not null check (points_awarded >= 0),
  add check (is_correct or points_awarded = 0),
  -- a alternativa escolhida precisa ser da pergunta respondida
  add foreign key (selected_option_id, question_id)
    references public.question_options (id, question_id) on delete restrict;

create index attempt_answers_selected_option_idx
  on public.attempt_answers (selected_option_id, question_id);


-- =============================================================================
-- VIEW: catálogo (coluna nova só pode entrar no fim)
-- =============================================================================

create or replace view public.quiz_catalog
with (security_invoker = true)
as
select q.id                 as quiz_id,
       q.slug,
       q.title,
       q.description,
       c.slug               as category_slug,
       c.name               as category_name,
       v.id                 as published_version_id,
       v.version_number,
       v.published_at,
       (select count(*) from public.questions qq where qq.quiz_version_id = v.id) as question_count,
       (select coalesce(sum(qq.points), 0) from public.questions qq where qq.quiz_version_id = v.id) as max_score
  from public.quizzes q
  join public.categories c    on c.id = q.category_id
  join public.quiz_versions v on v.quiz_id = q.id and v.status = 'published'
 where q.is_active;


-- =============================================================================
-- RPCs
-- =============================================================================

create or replace function public.start_attempt(p_quiz_id uuid)
returns public.quiz_attempts
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user       uuid := auth.uid();
  v_attempt    public.quiz_attempts;
  v_version_id uuid;
  v_total      integer;
  v_max_score  integer;
begin
  if v_user is null then
    raise exception 'Não autenticado' using errcode = '28000';
  end if;

  select * into v_attempt
    from public.quiz_attempts
   where user_id = v_user and quiz_id = p_quiz_id and status = 'in_progress';
  if found then
    return v_attempt;
  end if;

  select v.id into v_version_id
    from public.quiz_versions v
    join public.quizzes q on q.id = v.quiz_id
   where v.quiz_id = p_quiz_id and v.status = 'published' and q.is_active;
  if v_version_id is null then
    raise exception 'Quiz inexistente, inativo ou sem versão publicada' using errcode = 'P0002';
  end if;

  select count(*), sum(points) into v_total, v_max_score
    from public.questions where quiz_version_id = v_version_id;

  -- só a 1ª partida do usuário nesta versão vale para o ranking
  insert into public.quiz_attempts
         (user_id, quiz_id, quiz_version_id, total_questions, max_score, is_ranked)
  values (
    v_user, p_quiz_id, v_version_id, v_total, v_max_score,
    not exists (select 1 from public.quiz_attempts
                 where user_id = v_user and quiz_version_id = v_version_id)
  )
  on conflict (user_id, quiz_id) where status = 'in_progress' do nothing
  returning * into v_attempt;

  if not found then  -- corrida: outra requisição criou a tentativa no meio-tempo
    select * into v_attempt
      from public.quiz_attempts
     where user_id = v_user and quiz_id = p_quiz_id and status = 'in_progress';
  end if;

  return v_attempt;
end;
$$;


-- Assinatura e retorno mudam: precisa recriar (e refazer os grants, no fim).
drop function public.submit_answer(uuid, uuid, boolean);

-- Registra a alternativa escolhida e devolve correção, pontos, explicação e fonte.
create function public.submit_answer(
  p_attempt_id  uuid,
  p_question_id uuid,
  p_option_id   uuid
)
returns table (
  is_correct        boolean,
  correct_option_id uuid,
  points_awarded    integer,
  explanation       text,
  source_url        text
)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_attempt     public.quiz_attempts;
  v_correct_id  uuid;
  v_explanation text;
  v_source_url  text;
  v_points      integer;
  v_is_correct  boolean;
  v_awarded     integer;
begin
  if p_option_id is null then
    raise exception 'Alternativa obrigatória' using errcode = '22004';
  end if;

  select * into v_attempt
    from public.quiz_attempts
   where id = p_attempt_id and user_id = auth.uid()
   for update;
  if not found then
    raise exception 'Tentativa não encontrada' using errcode = 'P0002';
  end if;
  if v_attempt.status <> 'in_progress' then
    raise exception 'Tentativa já encerrada' using errcode = 'P0001';
  end if;

  select s.correct_option_id, s.explanation, s.source_url, q.points
    into v_correct_id, v_explanation, v_source_url, v_points
    from public.question_solutions s
    join public.questions q on q.id = s.question_id
   where s.question_id = p_question_id
     and q.quiz_version_id = v_attempt.quiz_version_id;
  if not found then
    raise exception 'Pergunta não pertence à versão desta tentativa' using errcode = 'P0002';
  end if;

  if not exists (select 1 from public.question_options o
                  where o.id = p_option_id and o.question_id = p_question_id) then
    raise exception 'Alternativa não pertence a esta pergunta' using errcode = 'P0002';
  end if;

  v_is_correct := (v_correct_id = p_option_id);
  v_awarded    := case when v_is_correct then v_points else 0 end;

  insert into public.attempt_answers
         (attempt_id, quiz_version_id, question_id, selected_option_id, is_correct, points_awarded)
  values (p_attempt_id, v_attempt.quiz_version_id, p_question_id, p_option_id, v_is_correct, v_awarded)
  on conflict (attempt_id, question_id) do nothing;
  if not found then
    raise exception 'Pergunta já respondida nesta tentativa' using errcode = '23505';
  end if;

  if v_is_correct then
    update public.quiz_attempts
       set correct_count = correct_count + 1,
           score         = score + v_awarded
     where id = p_attempt_id;
  end if;

  is_correct        := v_is_correct;
  correct_option_id := v_correct_id;
  points_awarded    := v_awarded;
  explanation       := v_explanation;
  source_url        := v_source_url;
  return next;
end;
$$;


-- Encerra a tentativa. Perguntas não respondidas contam como erro (0 pontos).
create or replace function public.finish_attempt(p_attempt_id uuid)
returns public.quiz_attempts
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_attempt public.quiz_attempts;
begin
  update public.quiz_attempts a
     set status        = 'finished',
         finished_at   = now(),
         correct_count = t.correct_count,
         score         = t.score
    from (select count(*) filter (where aa.is_correct) as correct_count,
                 coalesce(sum(aa.points_awarded), 0)   as score
            from public.attempt_answers aa
           where aa.attempt_id = p_attempt_id) t
   where a.id = p_attempt_id
     and a.user_id = auth.uid()
     and a.status = 'in_progress'
  returning a.* into v_attempt;

  if not found then
    raise exception 'Tentativa não encontrada ou já encerrada' using errcode = 'P0002';
  end if;
  return v_attempt;
end;
$$;


-- Colunas de retorno mudam: precisa recriar.
drop function public.get_leaderboard(uuid, integer);

-- Ranking de uma versão: só a 1ª partida de cada usuário nela (is_ranked),
-- já encerrada, ordenada por pontos e depois por acertos.
-- Empates dividem a posição (1, 1, 2, ...).
create function public.get_leaderboard(
  p_quiz_version_id uuid,
  p_limit           integer default 50
)
returns table (
  rank_position   bigint,
  user_id         uuid,
  name            text,
  score           integer,
  max_score       integer,
  correct_count   integer,
  total_questions integer,
  finished_at     timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  with best as (
    select a.user_id, a.score, a.max_score, a.correct_count, a.total_questions, a.finished_at
      from public.quiz_attempts a
     where a.quiz_version_id = p_quiz_version_id
       and a.is_ranked
       and a.status <> 'in_progress'
       and exists (select 1 from public.quiz_versions v
                    where v.id = p_quiz_version_id and v.status <> 'draft')
  )
  select dense_rank() over (order by b.score desc, b.correct_count desc),
         b.user_id, p.name, b.score, b.max_score, b.correct_count, b.total_questions, b.finished_at
    from best b
    join public.profiles p on p.id = b.user_id
   order by 1, p.name
   limit least(greatest(coalesce(p_limit, 50), 1), 100);
$$;


-- Cria (ou devolve) o rascunho da próxima versão, copiando perguntas,
-- alternativas e gabarito da versão publicada (ou da última, se nenhuma estiver publicada).
create or replace function public.create_quiz_draft(p_quiz_id uuid, p_changelog text default null)
returns public.quiz_versions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_draft      public.quiz_versions;
  v_source_id  uuid;
  v_next       integer;
  v_question   record;
  v_new_qid    uuid;
begin
  if not private.is_editor() then
    raise exception 'Sem permissão' using errcode = '42501';
  end if;

  -- serializa criação de versões do mesmo quiz
  perform 1 from public.quizzes where id = p_quiz_id for update;
  if not found then
    raise exception 'Quiz não encontrado' using errcode = 'P0002';
  end if;

  select * into v_draft from public.quiz_versions where quiz_id = p_quiz_id and status = 'draft';
  if found then
    return v_draft;
  end if;

  select id into v_source_id
    from public.quiz_versions
   where quiz_id = p_quiz_id
   order by (status = 'published') desc, version_number desc
   limit 1;

  select coalesce(max(version_number), 0) + 1 into v_next
    from public.quiz_versions where quiz_id = p_quiz_id;

  insert into public.quiz_versions (quiz_id, version_number, changelog, created_by)
  values (p_quiz_id, v_next, p_changelog, auth.uid())
  returning * into v_draft;

  if v_source_id is not null then
    for v_question in
      select * from public.questions where quiz_version_id = v_source_id order by sort_order
    loop
      insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
      values (v_draft.id, v_question.sort_order, v_question.statement,
              v_question.difficulty, v_question.points)
      returning id into v_new_qid;

      insert into public.question_options (question_id, sort_order, body)
      select v_new_qid, o.sort_order, o.body
        from public.question_options o
       where o.question_id = v_question.id;

      -- a alternativa certa da cópia é a de mesma sort_order
      insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
      select v_new_qid, new_o.id, s.explanation, s.source_url
        from public.question_solutions s
        join public.question_options old_o on old_o.id = s.correct_option_id
        join public.question_options new_o on new_o.question_id = v_new_qid
                                          and new_o.sort_order = old_o.sort_order
       where s.question_id = v_question.id;
    end loop;
  end if;

  return v_draft;
end;
$$;


-- Valida e publica um rascunho; a versão publicada anterior vira 'archived'.
-- Tentativas em andamento na versão anterior continuam normalmente.
create or replace function public.publish_quiz_version(p_version_id uuid)
returns public.quiz_versions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_version public.quiz_versions;
  v_problem text;
begin
  if not private.is_editor() then
    raise exception 'Sem permissão' using errcode = '42501';
  end if;

  select * into v_version from public.quiz_versions where id = p_version_id;
  if not found then
    raise exception 'Versão não encontrada' using errcode = 'P0002';
  end if;

  perform 1 from public.quizzes where id = v_version.quiz_id for update;

  select * into v_version from public.quiz_versions where id = p_version_id for update;
  if v_version.status <> 'draft' then
    raise exception 'Apenas rascunhos podem ser publicados' using errcode = 'P0001';
  end if;

  if not exists (select 1 from public.questions where quiz_version_id = p_version_id) then
    raise exception 'A versão precisa ter pelo menos uma pergunta' using errcode = 'P0001';
  end if;

  select case
           when (select count(*) from public.question_options o where o.question_id = q.id) < 2
             then format('Pergunta #%s: precisa de pelo menos 2 alternativas', q.sort_order)
           else format('Pergunta #%s: alternativa correta não definida', q.sort_order)
         end
    into v_problem
    from public.questions q
   where q.quiz_version_id = p_version_id
     and ((select count(*) from public.question_options o where o.question_id = q.id) < 2
          or not exists (select 1 from public.question_solutions s where s.question_id = q.id))
   order by q.sort_order
   limit 1;
  if v_problem is not null then
    raise exception '%', v_problem using errcode = 'P0001';
  end if;

  update public.quiz_versions
     set status = 'archived', archived_at = now()
   where quiz_id = v_version.quiz_id and status = 'published';

  update public.quiz_versions
     set status = 'published', published_at = now()
   where id = p_version_id
  returning * into v_version;

  return v_version;
end;
$$;


-- =============================================================================
-- ROW LEVEL SECURITY
-- =============================================================================

alter table public.question_options enable row level security;

-- alternativas: mesma visibilidade das perguntas; staff escreve (trigger garante draft)
create policy "question_options: ler" on public.question_options
  for select to authenticated
  using (
    (select private.is_editor())
    or exists (select 1
                 from public.questions qq
                 join public.quiz_versions v on v.id = qq.quiz_version_id
                where qq.id = question_options.question_id and v.status <> 'draft')
  );
create policy "question_options: staff insere" on public.question_options
  for insert to authenticated with check ((select private.is_editor()));
create policy "question_options: staff edita" on public.question_options
  for update to authenticated using ((select private.is_editor()));
create policy "question_options: staff remove" on public.question_options
  for delete to authenticated using ((select private.is_editor()));


-- =============================================================================
-- GRANTS
-- =============================================================================

-- tabela nova recebe os defaults do Supabase; aplica o mesmo aperto da migration inicial
revoke all on public.question_options from anon;
revoke truncate, references, trigger on public.question_options from authenticated;
grant select, insert, update, delete on public.question_options to authenticated;

-- funções recriadas voltam com EXECUTE para PUBLIC
revoke execute on function public.submit_answer(uuid, uuid, uuid)       from public, anon;
revoke execute on function public.get_leaderboard(uuid, integer)        from public, anon;
grant  execute on function public.submit_answer(uuid, uuid, uuid)       to authenticated;
grant  execute on function public.get_leaderboard(uuid, integer)        to authenticated;
