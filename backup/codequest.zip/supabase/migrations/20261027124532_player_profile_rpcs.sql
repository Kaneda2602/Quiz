-- =============================================================================
-- Quiz App — perfil do jogador e leitura da tentativa via RPC
--
--   * profiles.name       -> passa a aceitar nulo: nulo = jogador ainda não se identificou
--   * handle_new_user     -> não inventa mais nome a partir do email
--   * get_my_profile      -> perfil do usuário logado
--   * set_my_name         -> define/troca o nome do jogador
--   * get_attempt_questions -> as 10 perguntas sorteadas, com alternativas (sem gabarito)
--   * get_leaderboard     -> jogador sem nome aparece como 'Jogador'
-- =============================================================================


-- =============================================================================
-- PERFIS
-- =============================================================================

-- o check de tamanho continua valendo quando o nome existe
alter table public.profiles alter column name drop not null;

-- Nome só vem de metadados explícitos do cadastro (ex.: OAuth); senão fica nulo
-- e o app pede na tela de identificação.
create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, name, email)
  values (
    new.id,
    -- corta em 100 para não violar o check e derrubar o cadastro (ex.: nome longo vindo do OAuth)
    left(coalesce(
      nullif(trim(new.raw_user_meta_data ->> 'name'), ''),
      nullif(trim(new.raw_user_meta_data ->> 'full_name'), '')
    ), 100),
    new.email
  );
  return new;
end;
$$;


-- =============================================================================
-- RPCs
-- =============================================================================

create or replace function public.get_my_profile()
returns table (id uuid, name text, email text)
language sql
stable
security definer
set search_path = ''
as $$
  select p.id, p.name, p.email
    from public.profiles p
   where p.id = (select auth.uid());
$$;


create or replace function public.set_my_name(p_name text)
returns table (id uuid, name text, email text)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_name text := trim(p_name);
begin
  if auth.uid() is null then
    raise exception 'Não autenticado' using errcode = '28000';
  end if;
  if v_name is null or char_length(v_name) not between 2 and 40 then
    raise exception 'O nome precisa ter entre 2 e 40 caracteres' using errcode = '22023';
  end if;

  return query
  update public.profiles p
     set name = v_name
   where p.id = auth.uid()
  returning p.id, p.name, p.email;
end;
$$;


-- Perguntas sorteadas da tentativa, na ordem do sorteio, com as alternativas.
-- Para as já respondidas devolve a escolha e o acerto (permite retomar a partida).
create or replace function public.get_attempt_questions(p_attempt_id uuid)
returns table (
  question_id        uuid,
  sort_order         integer,
  statement          text,
  difficulty         public.question_difficulty,
  points             integer,
  options            jsonb,
  selected_option_id uuid,
  is_correct         boolean
)
language sql
stable
security definer
set search_path = ''
as $$
  select aq.question_id,
         aq.sort_order,
         q.statement,
         q.difficulty,
         aq.points,
         (select jsonb_agg(jsonb_build_object('id', o.id, 'sort_order', o.sort_order, 'body', o.body)
                           order by o.sort_order)
            from public.question_options o
           where o.question_id = aq.question_id),
         aa.selected_option_id,
         aa.is_correct
    from public.attempt_questions aq
    join public.quiz_attempts a on a.id = aq.attempt_id
    join public.questions q     on q.id = aq.question_id
    left join public.attempt_answers aa
           on aa.attempt_id = aq.attempt_id and aa.question_id = aq.question_id
   where aq.attempt_id = p_attempt_id
     and a.user_id = (select auth.uid())
   order by aq.sort_order;
$$;


-- Mesmo ranking; só troca nome nulo por 'Jogador'.
create or replace function public.get_leaderboard(
  p_quiz_version_id uuid,
  p_limit           integer default 50
)
returns table (
  rank_position   bigint,
  user_id         uuid,
  name            text,
  score           integer,
  max_score       integer,
  correct_count   integer,
  total_questions integer,
  finished_at     timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  with best as (
    select a.user_id, a.score, a.max_score, a.correct_count, a.total_questions, a.finished_at
      from public.quiz_attempts a
     where a.quiz_version_id = p_quiz_version_id
       and a.is_ranked
       and a.status <> 'in_progress'
       and exists (select 1 from public.quiz_versions v
                    where v.id = p_quiz_version_id and v.status <> 'draft')
  )
  select dense_rank() over (order by b.score desc, b.correct_count desc),
         b.user_id, coalesce(p.name, 'Jogador'), b.score, b.max_score,
         b.correct_count, b.total_questions, b.finished_at
    from best b
    join public.profiles p on p.id = b.user_id
   order by 1, 3
   limit least(greatest(coalesce(p_limit, 50), 1), 100);
$$;


-- =============================================================================
-- GRANTS
-- =============================================================================

revoke execute on function public.get_my_profile()                  from public, anon;
revoke execute on function public.set_my_name(text)                 from public, anon;
revoke execute on function public.get_attempt_questions(uuid)       from public, anon;
grant  execute on function public.get_my_profile()                  to authenticated;
grant  execute on function public.set_my_name(text)                 to authenticated;
grant  execute on function public.get_attempt_questions(uuid)       to authenticated;
