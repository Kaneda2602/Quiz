-- =============================================================================
-- Quiz App — sorteio das perguntas de cada tentativa
--
-- Cada tentativa passa a ter exatamente 10 perguntas sorteadas da versão:
--   3 fáceis  x 10 pts =  30
--   4 médias  x 20 pts =  80
--   3 difíceis x 30 pts = 90
--                        ----
--                         200 pts (máximo por questionário)
--
--   * attempt_questions -> perguntas sorteadas da tentativa, com ordem e pontos
--   * start_attempt     -> sorteia e grava as 10 perguntas
--   * submit_answer     -> só aceita perguntas sorteadas; pontua pela tentativa
--   * publish_quiz_version -> exige perguntas suficientes por dificuldade
--   * quiz_catalog      -> question_count / max_score refletem o questionário
-- =============================================================================


-- =============================================================================
-- TENTATIVAS
-- =============================================================================

create table public.attempt_questions (
  attempt_id      uuid not null,
  quiz_version_id uuid not null,
  question_id     uuid not null,
  sort_order      integer not null check (sort_order between 1 and 10),
  points          integer not null check (points in (10, 20, 30)),
  primary key (attempt_id, question_id),
  unique (attempt_id, sort_order),
  -- as FKs compostas garantem que a pergunta é da versão da tentativa
  foreign key (attempt_id, quiz_version_id)
    references public.quiz_attempts (id, quiz_version_id) on delete cascade,
  foreign key (question_id, quiz_version_id)
    references public.questions (id, quiz_version_id) on delete restrict
);

create index attempt_questions_question_idx
  on public.attempt_questions (question_id, quiz_version_id);

-- tentativas novas sempre valem no máximo 200 pontos (não há tentativas antigas)
alter table public.quiz_attempts
  add check (total_questions = 10 and max_score = 200);


-- =============================================================================
-- VIEW: catálogo
-- =============================================================================

create or replace view public.quiz_catalog
with (security_invoker = true)
as
select q.id                 as quiz_id,
       q.slug,
       q.title,
       q.description,
       c.slug               as category_slug,
       c.name               as category_name,
       v.id                 as published_version_id,
       v.version_number,
       v.published_at,
       10::bigint           as question_count,
       200::bigint          as max_score
  from public.quizzes q
  join public.categories c    on c.id = q.category_id
  join public.quiz_versions v on v.quiz_id = q.id and v.status = 'published'
 where q.is_active;


-- =============================================================================
-- RPCs
-- =============================================================================

-- Inicia uma tentativa na versão publicada sorteando 3 fáceis, 4 médias e 3 difíceis
-- (nessa ordem), ou retoma a que já está em andamento.
create or replace function public.start_attempt(p_quiz_id uuid)
returns public.quiz_attempts
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user       uuid := auth.uid();
  v_attempt    public.quiz_attempts;
  v_version_id uuid;
begin
  if v_user is null then
    raise exception 'Não autenticado' using errcode = '28000';
  end if;

  select * into v_attempt
    from public.quiz_attempts
   where user_id = v_user and quiz_id = p_quiz_id and status = 'in_progress';
  if found then
    return v_attempt;
  end if;

  select v.id into v_version_id
    from public.quiz_versions v
    join public.quizzes q on q.id = v.quiz_id
   where v.quiz_id = p_quiz_id and v.status = 'published' and q.is_active;
  if v_version_id is null then
    raise exception 'Quiz inexistente, inativo ou sem versão publicada' using errcode = 'P0002';
  end if;

  -- só a 1ª partida do usuário nesta versão vale para o ranking
  insert into public.quiz_attempts
         (user_id, quiz_id, quiz_version_id, total_questions, max_score, is_ranked)
  values (
    v_user, p_quiz_id, v_version_id, 10, 200,
    not exists (select 1 from public.quiz_attempts
                 where user_id = v_user and quiz_version_id = v_version_id)
  )
  on conflict (user_id, quiz_id) where status = 'in_progress' do nothing
  returning * into v_attempt;

  if not found then  -- corrida: outra requisição criou a tentativa no meio-tempo
    select * into v_attempt
      from public.quiz_attempts
     where user_id = v_user and quiz_id = p_quiz_id and status = 'in_progress';
    return v_attempt;
  end if;

  insert into public.attempt_questions (attempt_id, quiz_version_id, question_id, sort_order, points)
  select v_attempt.id, v_version_id, d.id,
         row_number() over (order by d.difficulty, d.draw),
         d.points
    from (select q.id, q.difficulty, random() as draw,
                 row_number() over (partition by q.difficulty order by random()) as pick,
                 case q.difficulty when 'easy' then 10 when 'medium' then 20 else 30 end as points,
                 case q.difficulty when 'easy' then 3  when 'medium' then 4  else 3  end as quota
            from public.questions q
           where q.quiz_version_id = v_version_id) d
   where d.pick <= d.quota;

  -- versões publicadas antes desta regra podem não ter perguntas suficientes
  if (select count(*) from public.attempt_questions where attempt_id = v_attempt.id) <> 10 then
    raise exception 'A versão publicada não tem perguntas suficientes (3 fáceis, 4 médias e 3 difíceis)'
      using errcode = 'P0001';
  end if;

  return v_attempt;
end;
$$;


-- Registra a alternativa escolhida e devolve correção, pontos, explicação e fonte.
-- A pergunta precisa ter sido sorteada na tentativa; os pontos vêm do sorteio.
create or replace function public.submit_answer(
  p_attempt_id  uuid,
  p_question_id uuid,
  p_option_id   uuid
)
returns table (
  is_correct        boolean,
  correct_option_id uuid,
  points_awarded    integer,
  explanation       text,
  source_url        text
)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_attempt     public.quiz_attempts;
  v_correct_id  uuid;
  v_explanation text;
  v_source_url  text;
  v_points      integer;
  v_is_correct  boolean;
  v_awarded     integer;
begin
  if p_option_id is null then
    raise exception 'Alternativa obrigatória' using errcode = '22004';
  end if;

  select * into v_attempt
    from public.quiz_attempts
   where id = p_attempt_id and user_id = auth.uid()
   for update;
  if not found then
    raise exception 'Tentativa não encontrada' using errcode = 'P0002';
  end if;
  if v_attempt.status <> 'in_progress' then
    raise exception 'Tentativa já encerrada' using errcode = 'P0001';
  end if;

  select s.correct_option_id, s.explanation, s.source_url, aq.points
    into v_correct_id, v_explanation, v_source_url, v_points
    from public.attempt_questions aq
    join public.question_solutions s on s.question_id = aq.question_id
   where aq.attempt_id = p_attempt_id
     and aq.question_id = p_question_id;
  if not found then
    raise exception 'Pergunta não pertence a esta tentativa' using errcode = 'P0002';
  end if;

  if not exists (select 1 from public.question_options o
                  where o.id = p_option_id and o.question_id = p_question_id) then
    raise exception 'Alternativa não pertence a esta pergunta' using errcode = 'P0002';
  end if;

  v_is_correct := (v_correct_id = p_option_id);
  v_awarded    := case when v_is_correct then v_points else 0 end;

  insert into public.attempt_answers
         (attempt_id, quiz_version_id, question_id, selected_option_id, is_correct, points_awarded)
  values (p_attempt_id, v_attempt.quiz_version_id, p_question_id, p_option_id, v_is_correct, v_awarded)
  on conflict (attempt_id, question_id) do nothing;
  if not found then
    raise exception 'Pergunta já respondida nesta tentativa' using errcode = '23505';
  end if;

  if v_is_correct then
    update public.quiz_attempts
       set correct_count = correct_count + 1,
           score         = score + v_awarded
     where id = p_attempt_id;
  end if;

  is_correct        := v_is_correct;
  correct_option_id := v_correct_id;
  points_awarded    := v_awarded;
  explanation       := v_explanation;
  source_url        := v_source_url;
  return next;
end;
$$;


-- Valida e publica um rascunho; a versão publicada anterior vira 'archived'.
-- Além das checagens por pergunta, exige banco suficiente para o sorteio.
create or replace function public.publish_quiz_version(p_version_id uuid)
returns public.quiz_versions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_version public.quiz_versions;
  v_problem text;
begin
  if not private.is_editor() then
    raise exception 'Sem permissão' using errcode = '42501';
  end if;

  select * into v_version from public.quiz_versions where id = p_version_id;
  if not found then
    raise exception 'Versão não encontrada' using errcode = 'P0002';
  end if;

  perform 1 from public.quizzes where id = v_version.quiz_id for update;

  select * into v_version from public.quiz_versions where id = p_version_id for update;
  if v_version.status <> 'draft' then
    raise exception 'Apenas rascunhos podem ser publicados' using errcode = 'P0001';
  end if;

  if not exists (select 1 from public.questions where quiz_version_id = p_version_id) then
    raise exception 'A versão precisa ter pelo menos uma pergunta' using errcode = 'P0001';
  end if;

  select case
           when (select count(*) from public.question_options o where o.question_id = q.id) < 2
             then format('Pergunta #%s: precisa de pelo menos 2 alternativas', q.sort_order)
           else format('Pergunta #%s: alternativa correta não definida', q.sort_order)
         end
    into v_problem
    from public.questions q
   where q.quiz_version_id = p_version_id
     and ((select count(*) from public.question_options o where o.question_id = q.id) < 2
          or not exists (select 1 from public.question_solutions s where s.question_id = q.id))
   order by q.sort_order
   limit 1;
  if v_problem is not null then
    raise exception '%', v_problem using errcode = 'P0001';
  end if;

  select format('A versão precisa de pelo menos %s pergunta(s) %s (tem %s)',
                r.quota, r.label, coalesce(c.total, 0))
    into v_problem
    from (values ('easy'::public.question_difficulty,   3, 'fáceis'),
                 ('medium'::public.question_difficulty, 4, 'médias'),
                 ('hard'::public.question_difficulty,   3, 'difíceis')) r (difficulty, quota, label)
    left join (select difficulty, count(*) as total
                 from public.questions
                where quiz_version_id = p_version_id
                group by difficulty) c on c.difficulty = r.difficulty
   where coalesce(c.total, 0) < r.quota
   order by r.difficulty
   limit 1;
  if v_problem is not null then
    raise exception '%', v_problem using errcode = 'P0001';
  end if;

  update public.quiz_versions
     set status = 'archived', archived_at = now()
   where quiz_id = v_version.quiz_id and status = 'published';

  update public.quiz_versions
     set status = 'published', published_at = now()
   where id = p_version_id
  returning * into v_version;

  return v_version;
end;
$$;


-- =============================================================================
-- ROW LEVEL SECURITY
-- =============================================================================

alter table public.attempt_questions enable row level security;

-- somente leitura do próprio; escrita só via RPC
create policy "attempt_questions: ler próprias" on public.attempt_questions
  for select to authenticated
  using (
    exists (select 1 from public.quiz_attempts a
             where a.id = attempt_questions.attempt_id
               and (a.user_id = (select auth.uid()) or (select private.has_role('admin'))))
  );


-- =============================================================================
-- GRANTS
-- =============================================================================

revoke all on public.attempt_questions from anon;
revoke all on public.attempt_questions from authenticated;
grant select on public.attempt_questions to authenticated;
