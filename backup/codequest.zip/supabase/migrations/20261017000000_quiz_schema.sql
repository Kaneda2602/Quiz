-- =============================================================================
-- Quiz App — schema inicial
--
-- Conceitos-chave:
--   * quizzes         -> identidade estável do quiz (nome, slug, categoria)
--   * quiz_versions   -> snapshot versionado do conteúdo (draft -> published -> archived)
--   * questions / question_solutions -> afirmações Certo/Errado de UMA versão,
--     imutável depois que a versão sai de 'draft'
--   * quiz_attempts   -> tentativa de um usuário, presa a uma versão específica
--   * attempt_answers -> respostas da tentativa (integridade garantida por FKs compostas)
--
-- Tentativas apontam para a versão em que começaram. Como versões publicadas/arquivadas
-- nunca mudam, publicar uma versão nova não interfere em quem já está respondendo.
-- =============================================================================


-- -----------------------------------------------------------------------------
-- Schema privado: helpers usados por RLS/triggers, NÃO exposto pela API REST
-- -----------------------------------------------------------------------------
create schema if not exists private;


-- -----------------------------------------------------------------------------
-- Tipos
-- -----------------------------------------------------------------------------
create type public.app_role            as enum ('admin', 'editor');
create type public.quiz_version_status as enum ('draft', 'published', 'archived');
create type public.attempt_status      as enum ('in_progress', 'finished', 'abandoned');


-- -----------------------------------------------------------------------------
-- Utilitário: updated_at
-- -----------------------------------------------------------------------------
create or replace function private.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;


-- =============================================================================
-- PERFIS E PAPÉIS
-- =============================================================================

create table public.profiles (
  id         uuid primary key references auth.users (id) on delete cascade,
  name       text not null check (char_length(name) between 1 and 100),
  email      text,  -- espelho de auth.users.email (nulo em login só por telefone/anônimo)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute function private.set_updated_at();

-- Cria o perfil automaticamente no cadastro (Supabase Auth)
create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, name, email)
  values (
    new.id,
    -- corta em 100 para não violar o check e derrubar o cadastro (ex.: nome longo vindo do OAuth)
    left(coalesce(
      nullif(trim(new.raw_user_meta_data ->> 'name'), ''),
      nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''),
      nullif(split_part(new.email, '@', 1), ''),
      'Jogador'
    ), 100),
    new.email
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function private.handle_new_user();

-- Mantém o email do perfil sincronizado quando o usuário troca de email no Auth
create or replace function private.handle_user_email_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.profiles set email = new.email where id = new.id;
  return new;
end;
$$;

create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row
  when (old.email is distinct from new.email)
  execute function private.handle_user_email_change();


-- Papéis de gestão. Jogador comum não tem linha aqui.
create table public.user_roles (
  user_id    uuid not null references auth.users (id) on delete cascade,
  role       public.app_role not null,
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

create or replace function private.has_role(p_role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.user_roles
     where user_id = (select auth.uid()) and role = p_role
  );
$$;

-- admin ou editor: pode criar/editar quizzes
create or replace function private.is_editor()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.user_roles
     where user_id = (select auth.uid()) and role in ('admin', 'editor')
  );
$$;


-- =============================================================================
-- CATÁLOGO: CATEGORIAS E QUIZZES
-- =============================================================================

create table public.categories (
  id          uuid primary key default gen_random_uuid(),
  slug        text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name        text not null check (char_length(name) between 2 and 60),
  description text,
  created_at  timestamptz not null default now()
);

create table public.quizzes (
  id          uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories (id) on delete restrict,
  slug        text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  title       text not null check (char_length(title) between 3 and 120),
  description text,
  is_active   boolean not null default true,  -- desliga novas tentativas sem apagar histórico
  created_by  uuid references auth.users (id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index quizzes_category_id_idx on public.quizzes (category_id);

create trigger quizzes_set_updated_at
  before update on public.quizzes
  for each row execute function private.set_updated_at();


-- =============================================================================
-- VERSIONAMENTO
-- =============================================================================

create table public.quiz_versions (
  id             uuid primary key default gen_random_uuid(),
  quiz_id        uuid not null references public.quizzes (id) on delete cascade,
  version_number integer not null check (version_number > 0),
  status         public.quiz_version_status not null default 'draft',
  changelog      text,
  created_by     uuid references auth.users (id) on delete set null,
  created_at     timestamptz not null default now(),
  published_at   timestamptz,
  archived_at    timestamptz,
  unique (quiz_id, version_number),
  unique (id, quiz_id),  -- alvo da FK composta em quiz_attempts
  check ((status = 'draft') = (published_at is null)),
  check ((status = 'archived') = (archived_at is not null))
);

-- No máximo 1 versão publicada e 1 rascunho por quiz
create unique index quiz_versions_one_published_idx
  on public.quiz_versions (quiz_id) where status = 'published';
create unique index quiz_versions_one_draft_idx
  on public.quiz_versions (quiz_id) where status = 'draft';

-- Regras de ciclo de vida: draft -> published -> archived, sem volta.
create or replace function private.guard_quiz_version()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'DELETE' then
    if old.status <> 'draft' then
      raise exception 'Versões publicadas/arquivadas não podem ser apagadas (desative o quiz)'
        using errcode = 'check_violation';
    end if;
    return old;
  end if;

  if new.quiz_id <> old.quiz_id or new.version_number <> old.version_number then
    raise exception 'quiz_id e version_number são imutáveis' using errcode = 'check_violation';
  end if;

  if new.status <> old.status and not (
       (old.status = 'draft'     and new.status = 'published') or
       (old.status = 'published' and new.status = 'archived')
     ) then
    raise exception 'Transição de status inválida: % -> %', old.status, new.status
      using errcode = 'check_violation';
  end if;

  return new;
end;
$$;

create trigger quiz_versions_guard
  before update or delete on public.quiz_versions
  for each row execute function private.guard_quiz_version();


-- =============================================================================
-- CONTEÚDO (pertence a uma versão)
-- =============================================================================

create table public.questions (
  id              uuid primary key default gen_random_uuid(),
  quiz_version_id uuid not null references public.quiz_versions (id) on delete cascade,
  sort_order      integer not null check (sort_order > 0),
  statement       text not null check (char_length(statement) > 0),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (quiz_version_id, sort_order) deferrable initially immediate,
  unique (id, quiz_version_id)  -- alvo da FK composta em attempt_answers
);

create trigger questions_set_updated_at
  before update on public.questions
  for each row execute function private.set_updated_at();

-- Cada pergunta é uma afirmação respondida com Certo (true) ou Errado (false).
-- Gabarito + explicação ficam fora de `questions` para que o RLS
-- esconda a resposta certa até o jogador responder aquela pergunta.
create table public.question_solutions (
  question_id    uuid primary key references public.questions (id) on delete cascade,
  correct_answer boolean not null,  -- true = Certo, false = Errado
  explanation    text
);


-- Imutabilidade: conteúdo só muda enquanto a versão é 'draft'.
-- "not found" é permitido de propósito: acontece no cascade ao apagar um rascunho.
create or replace function private.ensure_draft_version(p_version_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_status public.quiz_version_status;
begin
  select status into v_status from public.quiz_versions where id = p_version_id;
  if found and v_status <> 'draft' then
    raise exception 'Conteúdo de versões publicadas/arquivadas é imutável; crie um novo rascunho'
      using errcode = 'check_violation';
  end if;
end;
$$;

create or replace function private.ensure_draft_question(p_question_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_version_id uuid;
begin
  select quiz_version_id into v_version_id from public.questions where id = p_question_id;
  if found then
    perform private.ensure_draft_version(v_version_id);
  end if;
end;
$$;

create or replace function private.guard_question_content()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_table_name = 'questions' then
    if tg_op <> 'INSERT' then perform private.ensure_draft_version(old.quiz_version_id); end if;
    if tg_op <> 'DELETE' then perform private.ensure_draft_version(new.quiz_version_id); end if;
  else  -- question_solutions
    if tg_op <> 'INSERT' then perform private.ensure_draft_question(old.question_id); end if;
    if tg_op <> 'DELETE' then perform private.ensure_draft_question(new.question_id); end if;
  end if;

  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

create trigger questions_guard
  before insert or update or delete on public.questions
  for each row execute function private.guard_question_content();
create trigger question_solutions_guard
  before insert or update or delete on public.question_solutions
  for each row execute function private.guard_question_content();


-- =============================================================================
-- TENTATIVAS E RESPOSTAS
-- =============================================================================

create table public.quiz_attempts (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.profiles (id) on delete cascade,
  quiz_id         uuid not null,
  quiz_version_id uuid not null,
  status          public.attempt_status not null default 'in_progress',
  total_questions integer not null check (total_questions > 0),
  correct_count   integer not null default 0,
  -- true só na 1ª partida do usuário nesta versão: é a única que vale para o ranking
  is_ranked       boolean not null default false,
  started_at      timestamptz not null default now(),
  finished_at     timestamptz,
  -- versão precisa ser do mesmo quiz; restrict preserva histórico/ranking
  foreign key (quiz_version_id, quiz_id)
    references public.quiz_versions (id, quiz_id) on delete restrict,
  unique (id, quiz_version_id),  -- alvo da FK composta em attempt_answers
  check (correct_count between 0 and total_questions),
  check ((status = 'in_progress') = (finished_at is null))
);

-- Uma tentativa em andamento por usuário/quiz (qualquer versão)
create unique index quiz_attempts_one_in_progress_idx
  on public.quiz_attempts (user_id, quiz_id) where status = 'in_progress';
-- No máximo 1 partida ranqueada por usuário/versão
create unique index quiz_attempts_one_ranked_idx
  on public.quiz_attempts (user_id, quiz_version_id) where is_ranked;
-- Ranking por versão
create index quiz_attempts_leaderboard_idx
  on public.quiz_attempts (quiz_version_id, correct_count desc)
  where is_ranked and status <> 'in_progress';
-- Histórico do usuário
create index quiz_attempts_user_history_idx
  on public.quiz_attempts (user_id, started_at desc);

create table public.attempt_answers (
  attempt_id         uuid not null,
  quiz_version_id    uuid not null,
  question_id        uuid not null,
  selected_answer    boolean not null,  -- true = Certo, false = Errado
  is_correct         boolean not null,
  answered_at        timestamptz not null default now(),
  primary key (attempt_id, question_id),
  -- as FKs compostas garantem que a pergunta é da versão da tentativa
  foreign key (attempt_id, quiz_version_id)
    references public.quiz_attempts (id, quiz_version_id) on delete cascade,
  foreign key (question_id, quiz_version_id)
    references public.questions (id, quiz_version_id) on delete restrict
);

create index attempt_answers_question_idx on public.attempt_answers (question_id, quiz_version_id);

create or replace function private.has_answered(p_question_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
      from public.attempt_answers aa
      join public.quiz_attempts a on a.id = aa.attempt_id
     where aa.question_id = p_question_id
       and a.user_id = (select auth.uid())
  );
$$;


-- =============================================================================
-- VIEW: catálogo de quizzes jogáveis (respeita RLS de quem consulta)
-- =============================================================================

create view public.quiz_catalog
with (security_invoker = true)
as
select q.id                 as quiz_id,
       q.slug,
       q.title,
       q.description,
       c.slug               as category_slug,
       c.name               as category_name,
       v.id                 as published_version_id,
       v.version_number,
       v.published_at,
       (select count(*) from public.questions qq where qq.quiz_version_id = v.id) as question_count
  from public.quizzes q
  join public.categories c    on c.id = q.category_id
  join public.quiz_versions v on v.quiz_id = q.id and v.status = 'published'
 where q.is_active;


-- =============================================================================
-- RPCs (chamadas via supabase.rpc)
-- =============================================================================

-- Inicia uma tentativa na versão publicada, ou retoma a que já está em andamento
-- (mesmo que a versão dela já tenha sido arquivada).
create or replace function public.start_attempt(p_quiz_id uuid)
returns public.quiz_attempts
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user       uuid := auth.uid();
  v_attempt    public.quiz_attempts;
  v_version_id uuid;
  v_total      integer;
begin
  if v_user is null then
    raise exception 'Não autenticado' using errcode = '28000';
  end if;

  select * into v_attempt
    from public.quiz_attempts
   where user_id = v_user and quiz_id = p_quiz_id and status = 'in_progress';
  if found then
    return v_attempt;
  end if;

  select v.id into v_version_id
    from public.quiz_versions v
    join public.quizzes q on q.id = v.quiz_id
   where v.quiz_id = p_quiz_id and v.status = 'published' and q.is_active;
  if v_version_id is null then
    raise exception 'Quiz inexistente, inativo ou sem versão publicada' using errcode = 'P0002';
  end if;

  select count(*) into v_total from public.questions where quiz_version_id = v_version_id;

  -- só a 1ª partida do usuário nesta versão vale para o ranking
  insert into public.quiz_attempts (user_id, quiz_id, quiz_version_id, total_questions, is_ranked)
  values (
    v_user, p_quiz_id, v_version_id, v_total,
    not exists (select 1 from public.quiz_attempts
                 where user_id = v_user and quiz_version_id = v_version_id)
  )
  on conflict (user_id, quiz_id) where status = 'in_progress' do nothing
  returning * into v_attempt;

  if not found then  -- corrida: outra requisição criou a tentativa no meio-tempo
    select * into v_attempt
      from public.quiz_attempts
     where user_id = v_user and quiz_id = p_quiz_id and status = 'in_progress';
  end if;

  return v_attempt;
end;
$$;


-- Registra a resposta (true = Certo, false = Errado) e devolve correção + explicação.
create or replace function public.submit_answer(
  p_attempt_id  uuid,
  p_question_id uuid,
  p_answer      boolean
)
returns table (is_correct boolean, correct_answer boolean, explanation text)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_attempt    public.quiz_attempts;
  v_solution   public.question_solutions;
  v_is_correct boolean;
begin
  if p_answer is null then
    raise exception 'Resposta obrigatória (true = Certo, false = Errado)' using errcode = '22004';
  end if;

  select * into v_attempt
    from public.quiz_attempts
   where id = p_attempt_id and user_id = auth.uid()
   for update;
  if not found then
    raise exception 'Tentativa não encontrada' using errcode = 'P0002';
  end if;
  if v_attempt.status <> 'in_progress' then
    raise exception 'Tentativa já encerrada' using errcode = 'P0001';
  end if;

  select s.* into v_solution
    from public.question_solutions s
    join public.questions q on q.id = s.question_id
   where s.question_id = p_question_id
     and q.quiz_version_id = v_attempt.quiz_version_id;
  if not found then
    raise exception 'Pergunta não pertence à versão desta tentativa' using errcode = 'P0002';
  end if;

  v_is_correct := (v_solution.correct_answer = p_answer);

  insert into public.attempt_answers
         (attempt_id, quiz_version_id, question_id, selected_answer, is_correct)
  values (p_attempt_id, v_attempt.quiz_version_id, p_question_id, p_answer, v_is_correct)
  on conflict (attempt_id, question_id) do nothing;
  if not found then
    raise exception 'Pergunta já respondida nesta tentativa' using errcode = '23505';
  end if;

  if v_is_correct then
    update public.quiz_attempts set correct_count = correct_count + 1 where id = p_attempt_id;
  end if;

  is_correct        := v_is_correct;
  correct_answer    := v_solution.correct_answer;
  explanation       := v_solution.explanation;
  return next;
end;
$$;


-- Encerra a tentativa. Perguntas não respondidas contam como erro.
create or replace function public.finish_attempt(p_attempt_id uuid)
returns public.quiz_attempts
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_attempt public.quiz_attempts;
begin
  update public.quiz_attempts a
     set status        = 'finished',
         finished_at   = now(),
         correct_count = (select count(*) from public.attempt_answers aa
                           where aa.attempt_id = a.id and aa.is_correct)
   where a.id = p_attempt_id
     and a.user_id = auth.uid()
     and a.status = 'in_progress'
  returning * into v_attempt;

  if not found then
    raise exception 'Tentativa não encontrada ou já encerrada' using errcode = 'P0002';
  end if;
  return v_attempt;
end;
$$;


-- Desiste da tentativa. Permite começar de novo na versão atual.
-- Se era a partida ranqueada, ela entra no ranking com os acertos que tinha
-- (senão daria para ver o gabarito, abandonar e jogar de novo valendo).
create or replace function public.abandon_attempt(p_attempt_id uuid)
returns public.quiz_attempts
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_attempt public.quiz_attempts;
begin
  update public.quiz_attempts
     set status = 'abandoned', finished_at = now()
   where id = p_attempt_id and user_id = auth.uid() and status = 'in_progress'
  returning * into v_attempt;

  if not found then
    raise exception 'Tentativa não encontrada ou já encerrada' using errcode = 'P0002';
  end if;
  return v_attempt;
end;
$$;


-- Ranking de uma versão: só a 1ª partida de cada usuário nela (is_ranked),
-- já encerrada, ordenada só por acertos. Empates dividem a posição (1, 1, 2, ...).
create or replace function public.get_leaderboard(
  p_quiz_version_id uuid,
  p_limit           integer default 50
)
returns table (
  rank_position   bigint,
  user_id         uuid,
  name            text,
  correct_count   integer,
  total_questions integer,
  finished_at     timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  with best as (
    select a.user_id, a.correct_count, a.total_questions, a.finished_at
      from public.quiz_attempts a
     where a.quiz_version_id = p_quiz_version_id
       and a.is_ranked
       and a.status <> 'in_progress'
       and exists (select 1 from public.quiz_versions v
                    where v.id = p_quiz_version_id and v.status <> 'draft')
  )
  select dense_rank() over (order by b.correct_count desc),
         b.user_id, p.name, b.correct_count, b.total_questions, b.finished_at
    from best b
    join public.profiles p on p.id = b.user_id
   order by 1, p.name
   limit least(greatest(coalesce(p_limit, 50), 1), 100);
$$;


-- Cria (ou devolve) o rascunho da próxima versão, copiando o conteúdo da
-- versão publicada (ou da última, se nenhuma estiver publicada).
create or replace function public.create_quiz_draft(p_quiz_id uuid, p_changelog text default null)
returns public.quiz_versions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_draft      public.quiz_versions;
  v_source_id  uuid;
  v_next       integer;
  v_question   record;
  v_new_qid    uuid;
begin
  if not private.is_editor() then
    raise exception 'Sem permissão' using errcode = '42501';
  end if;

  -- serializa criação de versões do mesmo quiz
  perform 1 from public.quizzes where id = p_quiz_id for update;
  if not found then
    raise exception 'Quiz não encontrado' using errcode = 'P0002';
  end if;

  select * into v_draft from public.quiz_versions where quiz_id = p_quiz_id and status = 'draft';
  if found then
    return v_draft;
  end if;

  select id into v_source_id
    from public.quiz_versions
   where quiz_id = p_quiz_id
   order by (status = 'published') desc, version_number desc
   limit 1;

  select coalesce(max(version_number), 0) + 1 into v_next
    from public.quiz_versions where quiz_id = p_quiz_id;

  insert into public.quiz_versions (quiz_id, version_number, changelog, created_by)
  values (p_quiz_id, v_next, p_changelog, auth.uid())
  returning * into v_draft;

  if v_source_id is not null then
    for v_question in
      select * from public.questions where quiz_version_id = v_source_id order by sort_order
    loop
      insert into public.questions (quiz_version_id, sort_order, statement)
      values (v_draft.id, v_question.sort_order, v_question.statement)
      returning id into v_new_qid;

      insert into public.question_solutions (question_id, correct_answer, explanation)
      select v_new_qid, s.correct_answer, s.explanation
        from public.question_solutions s
       where s.question_id = v_question.id;
    end loop;
  end if;

  return v_draft;
end;
$$;


-- Valida e publica um rascunho; a versão publicada anterior vira 'archived'.
-- Tentativas em andamento na versão anterior continuam normalmente.
create or replace function public.publish_quiz_version(p_version_id uuid)
returns public.quiz_versions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_version public.quiz_versions;
  v_problem text;
begin
  if not private.is_editor() then
    raise exception 'Sem permissão' using errcode = '42501';
  end if;

  select * into v_version from public.quiz_versions where id = p_version_id;
  if not found then
    raise exception 'Versão não encontrada' using errcode = 'P0002';
  end if;

  perform 1 from public.quizzes where id = v_version.quiz_id for update;

  select * into v_version from public.quiz_versions where id = p_version_id for update;
  if v_version.status <> 'draft' then
    raise exception 'Apenas rascunhos podem ser publicados' using errcode = 'P0001';
  end if;

  if not exists (select 1 from public.questions where quiz_version_id = p_version_id) then
    raise exception 'A versão precisa ter pelo menos uma pergunta' using errcode = 'P0001';
  end if;

  select format('Pergunta #%s: gabarito (Certo/Errado) não definido', q.sort_order)
    into v_problem
    from public.questions q
   where q.quiz_version_id = p_version_id
     and not exists (select 1 from public.question_solutions s where s.question_id = q.id)
   order by q.sort_order
   limit 1;
  if v_problem is not null then
    raise exception '%', v_problem using errcode = 'P0001';
  end if;

  update public.quiz_versions
     set status = 'archived', archived_at = now()
   where quiz_id = v_version.quiz_id and status = 'published';

  update public.quiz_versions
     set status = 'published', published_at = now()
   where id = p_version_id
  returning * into v_version;

  return v_version;
end;
$$;


-- =============================================================================
-- ROW LEVEL SECURITY
-- =============================================================================

alter table public.profiles           enable row level security;
alter table public.user_roles         enable row level security;
alter table public.categories         enable row level security;
alter table public.quizzes            enable row level security;
alter table public.quiz_versions      enable row level security;
alter table public.questions          enable row level security;
alter table public.question_solutions enable row level security;
alter table public.quiz_attempts      enable row level security;
alter table public.attempt_answers    enable row level security;

-- profiles: cada um vê/edita o próprio; staff vê todos
create policy "profiles: ler próprio ou staff" on public.profiles
  for select to authenticated
  using (id = (select auth.uid()) or (select private.is_editor()));
create policy "profiles: editar próprio" on public.profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- user_roles: usuário vê os próprios papéis; admin gerencia
create policy "user_roles: ler próprio ou admin" on public.user_roles
  for select to authenticated
  using (user_id = (select auth.uid()) or (select private.has_role('admin')));
create policy "user_roles: admin insere" on public.user_roles
  for insert to authenticated
  with check ((select private.has_role('admin')));
create policy "user_roles: admin remove" on public.user_roles
  for delete to authenticated
  using ((select private.has_role('admin')));

-- categories: leitura pública; admin escreve
create policy "categories: leitura pública" on public.categories
  for select to anon, authenticated
  using (true);
create policy "categories: admin insere" on public.categories
  for insert to authenticated with check ((select private.has_role('admin')));
create policy "categories: admin edita" on public.categories
  for update to authenticated using ((select private.has_role('admin')));
create policy "categories: admin remove" on public.categories
  for delete to authenticated using ((select private.has_role('admin')));

-- quizzes: jogador vê quizzes com alguma versão publicada/arquivada; staff vê tudo
create policy "quizzes: ler" on public.quizzes
  for select to authenticated
  using (
    (select private.is_editor())
    or exists (select 1 from public.quiz_versions v
                where v.quiz_id = quizzes.id and v.status <> 'draft')
  );
create policy "quizzes: staff insere" on public.quizzes
  for insert to authenticated with check ((select private.is_editor()));
create policy "quizzes: staff edita" on public.quizzes
  for update to authenticated using ((select private.is_editor()));
create policy "quizzes: staff remove" on public.quizzes
  for delete to authenticated using ((select private.is_editor()));

-- quiz_versions: rascunhos só para staff. Publicação apenas via RPC.
create policy "quiz_versions: ler" on public.quiz_versions
  for select to authenticated
  using (status <> 'draft' or (select private.is_editor()));
create policy "quiz_versions: staff cria rascunho" on public.quiz_versions
  for insert to authenticated
  with check ((select private.is_editor()) and status = 'draft');
create policy "quiz_versions: staff edita rascunho" on public.quiz_versions
  for update to authenticated
  using ((select private.is_editor()) and status = 'draft')
  with check ((select private.is_editor()) and status = 'draft');
create policy "quiz_versions: staff apaga rascunho" on public.quiz_versions
  for delete to authenticated
  using ((select private.is_editor()) and status = 'draft');

-- questions: visíveis em versões não-rascunho; staff escreve (trigger garante draft)
create policy "questions: ler" on public.questions
  for select to authenticated
  using (
    (select private.is_editor())
    or exists (select 1 from public.quiz_versions v
                where v.id = questions.quiz_version_id and v.status <> 'draft')
  );
create policy "questions: staff insere" on public.questions
  for insert to authenticated with check ((select private.is_editor()));
create policy "questions: staff edita" on public.questions
  for update to authenticated using ((select private.is_editor()));
create policy "questions: staff remove" on public.questions
  for delete to authenticated using ((select private.is_editor()));

-- question_solutions: gabarito/explicação só depois que o jogador respondeu a pergunta
create policy "question_solutions: ler após responder" on public.question_solutions
  for select to authenticated
  using ((select private.is_editor()) or private.has_answered(question_id));
create policy "question_solutions: staff insere" on public.question_solutions
  for insert to authenticated with check ((select private.is_editor()));
create policy "question_solutions: staff edita" on public.question_solutions
  for update to authenticated using ((select private.is_editor()));
create policy "question_solutions: staff remove" on public.question_solutions
  for delete to authenticated using ((select private.is_editor()));

-- attempts / answers: somente leitura do próprio; escrita só via RPC
create policy "quiz_attempts: ler próprias" on public.quiz_attempts
  for select to authenticated
  using (user_id = (select auth.uid()) or (select private.has_role('admin')));

create policy "attempt_answers: ler próprias" on public.attempt_answers
  for select to authenticated
  using (
    exists (select 1 from public.quiz_attempts a
             where a.id = attempt_answers.attempt_id
               and (a.user_id = (select auth.uid()) or (select private.has_role('admin'))))
  );


-- =============================================================================
-- GRANTS (o Supabase concede ALL a anon/authenticated por padrão; aqui apertamos)
-- =============================================================================

revoke all on all tables in schema public from anon;
grant select on public.categories to anon;

-- TRUNCATE ignora RLS: nunca para clientes
revoke truncate, references, trigger on all tables in schema public from authenticated;

-- profiles: só o nome é editável pelo usuário (email vem do Auth)
revoke insert, update, delete on public.profiles from authenticated;
grant update (name) on public.profiles to authenticated;

-- tentativas e respostas: escrita exclusiva pelas RPCs
revoke insert, update, delete on public.quiz_attempts   from authenticated;
revoke insert, update, delete on public.attempt_answers from authenticated;

-- Funções nascem com EXECUTE para PUBLIC (default global, que um ALTER DEFAULT
-- PRIVILEGES por schema não consegue revogar); tiramos de todas e liberamos uma a uma.
revoke execute on all functions in schema private from public;

-- helpers privados usados nas policies
grant usage on schema private to authenticated;
grant execute on function private.is_editor()                    to authenticated;
grant execute on function private.has_role(public.app_role)      to authenticated;
grant execute on function private.has_answered(uuid)             to authenticated;

-- RPCs públicas: somente usuários logados
revoke execute on function public.start_attempt(uuid)                   from public, anon;
revoke execute on function public.submit_answer(uuid, uuid, boolean)    from public, anon;
revoke execute on function public.finish_attempt(uuid)                  from public, anon;
revoke execute on function public.abandon_attempt(uuid)                 from public, anon;
revoke execute on function public.get_leaderboard(uuid, integer)        from public, anon;
revoke execute on function public.create_quiz_draft(uuid, text)         from public, anon;
revoke execute on function public.publish_quiz_version(uuid)            from public, anon;

grant execute on function public.start_attempt(uuid)                    to authenticated;
grant execute on function public.submit_answer(uuid, uuid, boolean)     to authenticated;
grant execute on function public.finish_attempt(uuid)                   to authenticated;
grant execute on function public.abandon_attempt(uuid)                  to authenticated;
grant execute on function public.get_leaderboard(uuid, integer)         to authenticated;
grant execute on function public.create_quiz_draft(uuid, text)          to authenticated;
grant execute on function public.publish_quiz_version(uuid)             to authenticated;
