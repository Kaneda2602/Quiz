-- =============================================================================
-- Seed: questões CodeQuest (IA e FrontEnd)
-- Gerado a partir do PDF "Questões CodeQuest - IA e FrontEnd", com correções de
-- texto, fontes faltantes e pontuação. Cria 2 categorias, 2 quizzes e publica a v1.
-- Roda numa transação só: se o slug já existir, falha sem gravar nada.
-- =============================================================================

do $seed$
declare
  v_cat  uuid;
  v_quiz uuid;
  v_ver  uuid;
  v_q    uuid;
  v_opts uuid[];
begin

  -- ==========================================================================
  -- IA (21 questões)
  -- ==========================================================================
  insert into public.categories (slug, name, description)
  values ('ia', 'IA', 'Conceitos, uso responsável e riscos da Inteligência Artificial') returning id into v_cat;
  insert into public.quizzes (category_id, slug, title)
  values (v_cat, 'codequest-ia', 'CodeQuest: Inteligência Artificial') returning id into v_quiz;
  insert into public.quiz_versions (quiz_id, version_number, changelog)
  values (v_quiz, 1, 'Carga inicial a partir do PDF de questões') returning id into v_ver;

  -- IA #1
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 1, 'O que é Inteligência Artificial?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Uma tecnologia usada exclusivamente para criar robôs físicos'),
      (v_q, 2, 'Uma área da computação que desenvolve sistemas capazes de realizar tarefas que normalmente exigem capacidades humanas'),
      (v_q, 3, 'Um tipo de linguagem de programação'),
      (v_q, 4, 'Um sistema operacional para computadores')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'Inteligência Artificial é uma área da computação que busca desenvolver sistemas capazes de realizar tarefas, como poder reconhecer padrões, ver e identificar objetos, entender e responder à linguagem humana. São capazes de aprender com novas informações ou experiências prévias, realizar recomendações detalhadas para usuários e especialistas; agindo de forma independente dependendo do cenário.', 'https://www.ibm.com/br-pt/think/topics/artificial-intelligence');

  -- IA #2
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 2, 'Qual destas é uma aplicação de Inteligência Artificial?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Um sistema que recomenda filmes com base no comportamento do usuário'),
      (v_q, 2, 'Um cabo USB'),
      (v_q, 3, 'Um monitor desligado'),
      (v_q, 4, 'Um teclado mecânico sem software inteligente')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'Sistemas de recomendação podem utilizar técnicas de IA para identificar padrões no comportamento dos usuários e sugerir conteúdos. Esses sistemas são parte integrante da geração de vendas e do cultivo do engajamento para muitas empresas online, incluindo sites de comércio eletrônico, plataformas de streaming de mídia, mecanismos de pesquisa e redes de mídias sociais.', 'https://www.ibm.com/br-pt/think/topics/recommendation-engine');

  -- IA #3
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 3, 'O que é um chatbot?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Um programa destinado exclusivamente a jogos'),
      (v_q, 2, 'Um sistema capaz de interagir com usuários por meio de conversas'),
      (v_q, 3, 'Um componente físico de um computador'),
      (v_q, 4, 'Um banco de dados')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'Chatbots são sistemas desenvolvidos para interagir com pessoas por meio de linguagem natural, podendo utilizar IA para compreender e gerar respostas, porém podem fazer muito mais do que fornecê-las. Muitos se conectam a aplicações de negócios, bancos de dados e bases de conhecimento para que possam recuperar informações, concluir transações ou orientar os usuários em um processo. Também podem apoiar agentes humanos resolvendo solicitações de rotina e transferindo conversas mais complexas para um humano quando há necessidade de mais assistência.', 'https://www.ibm.com/br-pt/think/topics/chatbots');

  -- IA #4
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 4, 'O que significa “prompt” no contexto de uma IA generativa?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'A instrução ou solicitação fornecida à IA'),
      (v_q, 2, 'O nome do computador que executa a IA'),
      (v_q, 3, 'Um erro gerado pela IA'),
      (v_q, 4, 'O banco de dados utilizado pela IA')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'Um prompt é a entrada fornecida pelo usuário para orientar a IA sobre aquilo que deseja obter. A regra básica é que bons prompts equivalem a bons resultados. A IA generativa (gen AI) depende do refinamento iterativo de diferentes técnicas de engenharia de prompt para aprender efetivamente com diversos dados de entrada e se adaptar para minimizar vieses, confusão e produzir respostas mais precisas.', 'https://www.ibm.com/think/topics/prompt-engineering');

  -- IA #5
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 5, 'Qual destes conteúdos pode ser produzido por uma IA generativa?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Apenas textos'),
      (v_q, 2, 'Apenas números'),
      (v_q, 3, 'Somente páginas HTML'),
      (v_q, 4, 'Textos, imagens, áudio e outros tipos de conteúdo, dependendo do sistema')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'Sistemas generativos podem produzir diferentes modalidades de conteúdo, dependendo de suas capacidades. Esses modelos são o resultado de algoritmos treinados em grandes conjuntos de dados que permitem produzir novos conteúdos que imitam as características dos dados de treinamento.', 'https://www.ibm.com/br-pt/think/insights/ai-generated-content');

  -- IA #6
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 6, 'O que é uma “alucinação” de IA?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Quando a IA fica temporariamente desligada'),
      (v_q, 2, 'Quando a IA apresenta uma informação falsa ou inventada como se fosse verdadeira'),
      (v_q, 3, 'Quando a IA demora para responder'),
      (v_q, 4, 'Quando a IA recebe muitas perguntas')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'Uma alucinação ocorre quando um modelo de IA — frequentemente um chatbot de IA generativa ou uma ferramenta de visão computacional — produz uma resposta que pode parecer convincente, mas contém informação incorreta, inventada ou sem fundamento.', 'https://www.ibm.com/br-pt/think/topics/ai-hallucinations');

  -- IA #7
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 7, 'Por que uma resposta de IA deve ser verificada antes de ser utilizada em uma pesquisa?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Porque toda IA funciona aleatoriamente'),
      (v_q, 2, 'Porque respostas de IA nunca podem ser utilizadas'),
      (v_q, 3, 'Porque IA não consegue escrever textos'),
      (v_q, 4, 'Porque uma IA pode apresentar informações incorretas ou desatualizadas')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'Uma IA com alucinações pode produzir respostas incorretas e enganosas. Essas saídas falsas podem enganar os usuários e ser incorporadas a artefatos posteriores, espalhando ainda mais informações incorretas. portanto informações importantes devem ser conferidas em fontes confiáveis.', 'https://www.ibm.com/docs/en/watsonx/saas?topic=atlas-hallucination');

  -- IA #8
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 8, 'Qual atitude demonstra um uso responsável de IA?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Copiar qualquer resposta sem verificar'),
      (v_q, 2, 'Compartilhar informações pessoais para obter respostas melhores'),
      (v_q, 3, 'Utilizar a IA como ferramenta de apoio e verificar informações importantes'),
      (v_q, 4, 'Considerar a IA sempre mais inteligente que um ser humano')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], 'O uso responsável da IA envolve pensamento crítico, verificação das informações e cuidado com os dados fornecidos ao sistema, considerando o impacto social e os valores morais, legais e éticos.', 'https://www.ibm.com/br-pt/think/topics/responsible-ai');

  -- IA #9
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 9, 'Qual é um possível risco de utilizar dados pessoais em ferramentas de IA sem analisar suas políticas de privacidade?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'O computador necessariamente ficará mais rápido'),
      (v_q, 2, 'Os dados podem ser tratados de maneiras que o usuário não esperava'),
      (v_q, 3, 'A internet será automaticamente desligada'),
      (v_q, 4, 'O teclado poderá parar de funcionar')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'Antes de inserir informações pessoais, é importante compreender como o serviço trata, armazena e utiliza esses dados. Uma das razões pelas quais a IA representa um risco à privacidade de dados maior é o grande volume de informações em jogo. Texto, imagens ou vídeos são incluídos rotineiramente como dados de treinamento e, inevitavelmente, alguns desses dados são confidenciais: informações de saúde, dados pessoais de sites de redes sociais, dados financeiros pessoais, dados biométricos usados para reconhecimento facial e muito mais. Com o aumento da quantidade de dados confidenciais sendo coletados, armazenados e transmitidos, são maiores as chances de que pelo menos uma parte seja exposta ou implementada de maneiras que violem os direitos de privacidade.', 'https://www.ibm.com/br-pt/think/insights/ai-privacy');

  -- IA #10
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 10, 'Por que o viés nos dados pode ser um problema para sistemas de IA?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Porque a IA pode reproduzir ou ampliar padrões presentes nos dados'),
      (v_q, 2, 'Porque qualquer dado faz a IA parar de funcionar'),
      (v_q, 3, 'Porque dados impedem a utilização de algoritmos'),
      (v_q, 4, 'Porque IA não pode utilizar dados')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'O viés da IA, também chamado de viés do aprendizado de máquina ou viés do algoritmo, refere-se à ocorrência de resultados enviesados em decorrência de vieses humanos que distorcem os dados de treinamento originais ou o algoritmo de IA, levando a resultados distorcidos e a consequências potencialmente prejudiciais.', 'https://www.ibm.com/br-pt/think/topics/ai-bias');

  -- IA #11
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 11, 'Uma IA fornece uma referência bibliográfica que parece verdadeira, mas você não consegue encontrá-la em nenhuma biblioteca ou mecanismo de pesquisa. Qual é a atitude mais adequada?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Verificar a existência da fonte antes de utilizá-la'),
      (v_q, 2, 'Considerá-la verdadeira porque possui formato acadêmico'),
      (v_q, 3, 'Utilizá-la porque a IA provavelmente encontrou uma fonte privada'),
      (v_q, 4, 'Criar outras referências semelhantes')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'IAs podem gerar referências inexistentes. Uma referência deve ser confirmada antes de ser utilizada em um trabalho.', 'https://doutoranathalia.com.br/blog/como-verificar-referencias-sao-reais/');

  -- IA #12
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 12, 'Uma empresa utiliza IA para selecionar candidatos para uma vaga. Qual medida ajuda a reduzir riscos relacionados a decisões automatizadas?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Permitir que a IA tome todas as decisões sem supervisão'),
      (v_q, 2, 'Ignorar possíveis vieses porque a IA é matemática'),
      (v_q, 3, 'Avaliar os critérios utilizados e manter supervisão humana adequada'),
      (v_q, 4, 'Utilizar somente candidatos que a IA considerar perfeitos')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], 'Sistemas automatizados precisam ser avaliados quanto aos seus critérios, resultados e possíveis vieses, especialmente quando suas decisões afetam pessoas. Discriminação algorítmica ocorre quando um sistema automatizado produz resultados injustos, desproporcionais ou prejudiciais contra pessoas ou grupos. Isso pode acontecer mesmo quando o algoritmo não usa diretamente uma informação sensível, como raça, religião, saúde ou gênero.', 'https://prunzelfernandez.com.br/uso-de-ia-na-selecao-de-candidatos-limites-legais-e-riscos-trabalhistas/');

  -- IA #13
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 13, 'O que caracteriza melhor um deepfake?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Um arquivo de vídeo com baixa resolução'),
      (v_q, 2, 'Um vídeo gravado sem conexão com a internet'),
      (v_q, 3, 'Uma fotografia tirada com uma câmera profissional'),
      (v_q, 4, 'Um conteúdo sintético ou manipulado que pode representar uma pessoa dizendo ou fazendo algo que não ocorreu daquela maneira')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'Deepfakes utilizam técnicas de IA para criar ou modificar conteúdos de forma altamente realista. O Gerador cria conteúdo sintético, e um Discriminador determina se o conteúdo é real. Essa troca de informações acaba fazendo com que o conteúdo falso pareça o mais real possível. Entender a ameaça é o primeiro passo para se defender dela. Com mais treinamento de segurança do usuário final e o emprego de ferramentas emergentes de detecção de deepfake, organizações e indivíduos podem começar a combater essa nova ameaça.', 'https://www.ibm.com/br-pt/think/x-force/weaponizing-reality-evolution-deepfake-technology');

  -- IA #14
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 14, 'Um aluno utiliza IA para gerar um trabalho inteiro e entrega o resultado sem verificar as informações nem informar o uso da ferramenta quando isso é exigido. Qual é o principal problema?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'O computador utilizado pode ficar lento'),
      (v_q, 2, 'A IA utilizou muita memória'),
      (v_q, 3, 'Há questões relacionadas à autoria, responsabilidade e integridade acadêmica'),
      (v_q, 4, 'O trabalho necessariamente terá erros de português')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], 'A principal preocupação reside na autoria e na originalidade. Um texto acadêmico é, por definição, o resultado de pesquisa, análise crítica e argumentação original do autor. Quando a IA é utilizada para gerar seções substanciais ou até mesmo a totalidade de um texto, a linha entre a assistência e a substituição da autoria torna-se tênue. Isso levanta questões sérias sobre a integridade acadêmica e a capacidade do pesquisador em demonstrar um domínio genuíno do tema, algo essencial para essa trajetória. O uso de IA em atividades acadêmicas deve respeitar as regras da instituição e não elimina a responsabilidade do aluno pelo conteúdo entregue.', 'https://hed.pearson.com.br/blog/coluna-inside-higher-education/o-limite-da-inteligencia-artificial-em-textos-cientificos-academicos-uma-reflexao-necessaria');

  -- IA #15
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 15, 'Qual situação representa melhor o conceito de “human in the loop”?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Uma IA trabalha sem qualquer intervenção humana'),
      (v_q, 2, 'Uma pessoa participa da avaliação ou decisão envolvendo resultados produzidos pela IA'),
      (v_q, 3, 'Uma IA é desligada antes de produzir resultados'),
      (v_q, 4, 'Um computador executa dois programas simultaneamente')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], '“Human in the loop” é uma abordagem de AI e machine learning na qual as pessoas participam ativamente do treinamento, da supervisão ou da tomada de decisões de um sistema para melhorar a precisão, a segurança e o alinhamento ético. O "loop" descreve o ciclo básico: um modelo gera um resultado, uma pessoa o revisa ou corrige, e esse feedback retorna ao sistema. Cada correção ensina o modelo a se comportar mais de acordo com o que as pessoas esperam.', 'https://www.databricks.com/br/blog/human-in-the-loop');

  -- IA #16
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 16, 'Você recebe uma mensagem urgente dizendo que seu banco detectou uma fraude e deve clicar em um link imediatamente. Uma IA analisa a mensagem e diz que ela “parece legítima”. O que você deveria fazer?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Clicar, porque a IA confirmou'),
      (v_q, 2, 'Compartilhar a mensagem com outras pessoas'),
      (v_q, 3, 'Responder ao remetente solicitando sua senha'),
      (v_q, 4, 'Verificar a situação diretamente pelos canais oficiais do banco')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'Uma ferramenta de IA não deve substituir procedimentos de segurança. Em situações suspeitas, deve-se utilizar canais oficiais e independentes para verificar a informação. Um golpe de phishing é uma fraude digital onde criminosos se passam por entidades confiáveis (bancos, empresas, órgãos públicos) em e-mails, SMS ou mensagens para “pescar” dados confidenciais, como senhas e números de cartão, usando iscas como links falsos ou anexos maliciosos para roubar informações e dinheiro, exigindo atenção a erros de português, links suspeitos e urgência.', 'https://oespecialista.safra.com.br/phishing-como-se-proteger/');

  -- IA #17
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 17, 'Qual afirmação apresenta uma visão mais adequada sobre a confiabilidade de uma IA generativa?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Uma IA sempre sabe quando está errada'),
      (v_q, 2, 'Uma resposta bem escrita é necessariamente verdadeira'),
      (v_q, 3, 'A IA pode ser útil mesmo sem ser infalível, exigindo avaliação humana adequada'),
      (v_q, 4, 'Uma IA nunca deve ser utilizada para nenhuma finalidade')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], 'A utilidade de uma IA não significa que suas respostas sejam automaticamente verdadeiras. O usuário continua responsável por avaliar o resultado. Um modelo tem um desempenho mais confiável quando tem uma função clara e limitada. Defina o que o sistema deve fazer, quem o usará, em quais informações ele deve se basear e quais solicitações estão fora de seu escopo.', 'https://www.databricks.com/br/blog/ai-hallucinations');

  -- IA #18
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 18, 'Um sistema de IA foi treinado principalmente com dados que representam um determinado grupo de pessoas. Qual risco deve ser considerado?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'O sistema necessariamente deixará de funcionar'),
      (v_q, 2, 'O sistema pode apresentar desempenho desigual para grupos pouco representados'),
      (v_q, 3, 'O sistema não poderá gerar textos'),
      (v_q, 4, 'O sistema obrigatoriamente ficará mais curto')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'A representatividade e a qualidade dos dados podem influenciar o desempenho de um sistema para diferentes grupos. O viés na IA é um fenômeno que ocorre quando os sistemas de IA produzem sistematicamente resultados tendenciosos que favorecem ou prejudicam injustamente certos grupos ou indivíduos. Esses preconceitos podem se manifestar de várias maneiras, desde prejudicar certos grupos populacionais na procura de emprego até tratamento injusto em aplicações legais ou médicas.', 'https://www.activemind.legal/guides/bias-ai/');

  -- IA #19
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 19, 'Qual destas atitudes melhor representa pensamento crítico ao utilizar IA?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Aceitar a resposta quando ela estiver bem escrita'),
      (v_q, 2, 'Comparar a resposta com evidências, fontes e contexto antes de confiar nela'),
      (v_q, 3, 'Perguntar várias vezes até a IA fornecer a resposta desejada'),
      (v_q, 4, 'Considerar verdadeira a resposta com mais detalhes')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'Pensamento crítico envolve avaliar evidências e contexto, e não apenas a aparência ou a confiança da resposta. Um dos maiores riscos no uso da tecnologia é utilizá-la apenas para validar aquilo que a pessoa já pensa. O pensamento crítico, porém, exige justamente a disposição de confrontar ideias, reconhecer limitações e considerar perspectivas diferentes.', 'https://www.correiobraziliense.com.br/revista-do-correio/2026/09/7497950-pensamento-critico-na-era-da-inteligencia-artificial-7-dicas-para-desenvolver-essa-habilidade.html');

  -- IA #20
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 20, 'O que é Engenharia de Prompt (Prompt Engineering)?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'O processo de construir fisicamente os computadores utilizados por uma IA'),
      (v_q, 2, 'O processo de corrigir automaticamente todos os erros cometidos por uma IA'),
      (v_q, 3, 'Uma técnica utilizada exclusivamente para programar sistemas de inteligência artificial'),
      (v_q, 4, 'A prática de elaborar e aperfeiçoar instruções para orientar uma IA a produzir resultados mais adequados ao objetivo desejado')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'A Engenharia de Prompt consiste em criar, testar e aperfeiçoar instruções fornecidas a um sistema de IA para direcioná-lo de maneira mais clara e eficaz. Um bom prompt pode especificar, por exemplo, objetivo, contexto, formato da resposta, restrições e exemplos.', 'https://www.ibm.com/br-pt/think/topics/prompt-engineering');

  -- IA #21
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 21, 'Qual linguagem de programação é a mais utilizada em Inteligências Artificiais?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Lua'),
      (v_q, 2, 'C++'),
      (v_q, 3, 'Java'),
      (v_q, 4, 'Python')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'Uma das principais razões para a ampla adoção do Python é sua simplicidade: quanto menor a barreira de entrada de uma linguagem, maior tende a ser sua adoção. Python é fácil de aprender, de alto nível e de uso geral, e concentra as principais bibliotecas de IA e ciência de dados. Em 2024, ultrapassou o JavaScript como a linguagem mais usada no GitHub, impulsionado pelo crescimento da IA generativa.', 'https://github.blog/news-insights/octoverse/octoverse-2024/');

  -- mesmas validações de publish_quiz_version (a RPC exige editor logado)
  if exists (select 1 from public.questions qq
              where qq.quiz_version_id = v_ver
                and ((select count(*) from public.question_options o where o.question_id = qq.id) < 2
                     or not exists (select 1 from public.question_solutions s where s.question_id = qq.id))) then
    raise exception 'Seed IA: pergunta sem alternativas ou sem gabarito';
  end if;
  update public.quiz_versions set status = 'published', published_at = now() where id = v_ver;

  -- ==========================================================================
  -- FrontEnd (20 questões)
  -- ==========================================================================
  insert into public.categories (slug, name, description)
  values ('frontend', 'FrontEnd', 'HTML, CSS, JavaScript e acessibilidade na web') returning id into v_cat;
  insert into public.quizzes (category_id, slug, title)
  values (v_cat, 'codequest-frontend', 'CodeQuest: FrontEnd') returning id into v_quiz;
  insert into public.quiz_versions (quiz_id, version_number, changelog)
  values (v_quiz, 1, 'Carga inicial a partir do PDF de questões') returning id into v_ver;

  -- FrontEnd #1
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 1, 'Qual é a principal função do HTML?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Estruturar o conteúdo da página'),
      (v_q, 2, 'Criar exclusivamente animações'),
      (v_q, 3, 'Armazenar dados em um banco'),
      (v_q, 4, 'Controlar o servidor')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'HTML é utilizado para estruturar o conteúdo de uma página web. HTML (Linguagem de Marcação de HiperTexto) é o bloco de construção mais básico da web. Define o significado e a estrutura do conteúdo da web. Outras tecnologias além do HTML geralmente são usadas para descrever a aparência/apresentação (CSS) ou a funcionalidade/comportamento (JavaScript) de uma página da web.', 'https://developer.mozilla.org/pt-BR/docs/Web/HTML');

  -- FrontEnd #2
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 2, 'Qual linguagem é utilizada principalmente para definir a aparência de uma página web?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'SQL'),
      (v_q, 2, 'CSS'),
      (v_q, 3, 'Java'),
      (v_q, 4, 'Python')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'CSS é utilizado para definir aspectos visuais como cores, tamanhos, espaçamentos, posicionamento e fontes.', 'https://developer.mozilla.org/en-US/docs/Web/CSS/Guides');

  -- FrontEnd #3
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 3, 'Qual linguagem permite adicionar interatividade a uma página web?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'HTML'),
      (v_q, 2, 'CSS'),
      (v_q, 3, 'JavaScript'),
      (v_q, 4, 'SQL')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], 'JavaScript permite implementar comportamentos e interações dinâmicas nas páginas.', 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide');

  -- FrontEnd #4
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 4, 'Qual elemento HTML representa um link?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, '<img>'),
      (v_q, 2, '<url>'),
      (v_q, 3, '<linktext>'),
      (v_q, 4, '<a>')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'O elemento <a> (elemento âncora), com o atributo href, cria um hiperlink para páginas web, arquivos, endereços de e-mail, posições na mesma página ou qualquer outro endereço (URL). O conteúdo dentro de cada <a> deve indicar o destino do link.', 'https://developer.mozilla.org/pt-BR/docs/Web/HTML/Reference/Elements/a');

  -- FrontEnd #5
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 5, 'Qual elemento HTML é normalmente utilizado para representar o título principal de uma página?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, '<h1>'),
      (v_q, 2, '<title-main>'),
      (v_q, 3, '<header-text>'),
      (v_q, 4, '<heading>')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'Elementos de cabeçalho são implementados em seis níveis, <h1> é o mais importante e <h6> é o de menor importância. Um elemento de cabeçalho descreve brevemente o tópico da seção em que ele está. As informações de cabeçalho podem ser usadas por agentes de usuário, por exemplo, para construir uma tabela de conteúdos para um documento automaticamente.', 'https://developer.mozilla.org/pt-BR/docs/Web/HTML/Reference/Elements/Heading_Elements');

  -- FrontEnd #6
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 6, 'O que “display: flex” faz no CSS?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Esconde o elemento'),
      (v_q, 2, 'Ativa um modelo de layout baseado em Flexbox'),
      (v_q, 3, 'Transforma o elemento em uma imagem'),
      (v_q, 4, 'Executa JavaScript')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'Flexbox é um modelo de layout CSS que facilita a organização e o alinhamento dos elementos. Com display: flex, o elemento passa a ser um contêiner flexível e seus filhos diretos viram itens flexíveis, dispostos em linha ou em coluna. Dentro de um contêiner flex, floats não afetam os itens e as margens não colapsam.', 'https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Flexible_box_layout/Relationship_with_other_layout_methods');

  -- FrontEnd #7
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 7, 'Qual propriedade CSS altera a cor do texto?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'background-color'),
      (v_q, 2, 'font-color'),
      (v_q, 3, 'color'),
      (v_q, 4, 'text-background')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], 'A propriedade color define a cor do conteúdo textual de um elemento. É importante garantir que a taxa de contraste entre a cor do texto e o fundo sobre o qual o texto é colocado seja alta o suficiente para que pessoas com baixa visão consigam ler o conteúdo da página.', 'https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/color');

  -- FrontEnd #8
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 8, 'O que significa responsividade em um site?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'O site responde somente a comandos de voz'),
      (v_q, 2, 'O site funciona apenas em computadores'),
      (v_q, 3, 'O site possui respostas automáticas de IA'),
      (v_q, 4, 'O layout se adapta a diferentes tamanhos e dispositivos de tela')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'Um site responsivo adapta seu layout para diferentes larguras e condições de visualização. À medida que diferentes tamanhos de tela foram aparecendo, surgiu o conceito de web design responsivo (RWD), um conjunto de práticas que permite que páginas da Web alterem seu layout e aparência para se adequarem a diferentes larguras, resoluções etc.', 'https://developer.mozilla.org/pt-BR/docs/Learn_web_development/Core/CSS_layout/Responsive_Design#hist%C3%B3ria_dos_layouts_de_sites');

  -- FrontEnd #9
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 9, 'Qual pseudoclasse CSS é utilizada para aplicar estilos quando o mouse está sobre um elemento?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, ':click'),
      (v_q, 2, ':mouse'),
      (v_q, 3, ':hover'),
      (v_q, 4, ':cursor')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], ':hover permite definir estilos para quando o ponteiro do mouse está sobre o elemento. A pseudoclasse :hover corresponde a um elemento quando o usuário interage com ele usando um dispositivo apontador, geralmente ao mover o cursor sobre o elemento sem pressionar o botão do mouse.', 'https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Selectors/:hover');

  -- FrontEnd #10
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 10, 'Qual atributo HTML fornece um texto alternativo para uma imagem?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'description'),
      (v_q, 2, 'alt'),
      (v_q, 3, 'text'),
      (v_q, 4, 'alternative')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'O atributo alt fornece uma descrição alternativa da imagem e é importante para acessibilidade. A propriedade alt da interface HTMLImageElement fornece o texto exibido quando a imagem do elemento <img> não é mostrada — seja por um erro, porque o usuário desabilitou o carregamento de imagens ou porque a imagem ainda não terminou de carregar. Ela reflete o atributo alt do elemento <img>.', 'https://developer.mozilla.org/en-US/docs/Web/API/HTMLImageElement/alt');

  -- FrontEnd #11
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 11, 'Observe o código:

```js
let pontos = 10;
pontos = pontos + 5;
```

Qual será o valor de `pontos`?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, '15'),
      (v_q, 2, '10'),
      (v_q, 3, '5'),
      (v_q, 4, '105')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'O valor inicial é 10. Ao adicionar 5, a variável passa a armazenar 15. “let” declara uma variável local no escopo do bloco atual, opcionalmente iniciando-a com um valor.', 'https://developer.mozilla.org/pt-BR/docs/Web/JavaScript/Reference/Statements/let');

  -- FrontEnd #12
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 12, 'O que o seguinte código JavaScript faz?

```js
document.getElementById("botao")
```', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Cria automaticamente um botão'),
      (v_q, 2, 'Cria um banco de dados chamado botao'),
      (v_q, 3, 'Remove todos os botões'),
      (v_q, 4, 'Procura no documento um elemento cujo id seja "botao"')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'getElementById() procura um elemento HTML pelo valor de seu atributo id.', 'https://developer.mozilla.org/en-US/docs/Web/API/Document/getElementById');

  -- FrontEnd #13
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 13, 'Qual é a principal finalidade de uma classe CSS?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Identificar elementos que podem compartilhar determinadas regras de estilo'),
      (v_q, 2, 'Criar obrigatoriamente um banco de dados'),
      (v_q, 3, 'Executar funções JavaScript'),
      (v_q, 4, 'Substituir o HTML')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'Classes permitem aplicar regras CSS a um ou vários elementos que compartilham determinada característica.', 'https://developer.mozilla.org/pt-BR/docs/Web/CSS/Reference/Selectors/Class_selectors');

  -- FrontEnd #14
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 14, 'Qual prática melhora a acessibilidade de um formulário?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Remover todos os textos dos campos'),
      (v_q, 2, 'Utilizar somente cores para indicar erros'),
      (v_q, 3, 'Associar corretamente os campos aos seus respectivos rótulos'),
      (v_q, 4, 'Utilizar letras muito pequenas')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], 'Rótulos associados aos campos ajudam diferentes usuários, incluindo pessoas que utilizam tecnologias assistivas, a compreender a finalidade de cada campo.', 'https://developer.mozilla.org/pt-BR/docs/Web/HTML/Reference/Elements/label');

  -- FrontEnd #15
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 15, 'Por que utilizar HTML semântico é importante?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Porque elementos semânticos tornam o JavaScript desnecessário'),
      (v_q, 2, 'Porque ajudam a comunicar a estrutura e o significado do conteúdo'),
      (v_q, 3, 'Porque eliminam a necessidade de CSS'),
      (v_q, 4, 'Porque fazem qualquer site carregar instantaneamente')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'Elementos como <header>, <nav>, <main>, <article> e <footer> ajudam a representar semanticamente a estrutura do conteúdo.', 'https://developer.mozilla.org/pt-BR/docs/Glossary/Semantics');

  -- FrontEnd #16
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 16, 'O botão abaixo deveria executar uma função ao ser clicado:

```html
<button id="iniciar">Começar</button>
```

Qual opção JavaScript seleciona esse botão?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'document.findButton("iniciar")'),
      (v_q, 2, 'document.getElement("button")'),
      (v_q, 3, 'document.button("iniciar")'),
      (v_q, 4, 'document.getElementById("iniciar")')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[4], 'getElementById() seleciona o elemento que possui o id especificado.', 'https://developer.mozilla.org/en-US/docs/Web/API/Document/getElementById');

  -- FrontEnd #17
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 17, 'Um site possui texto cinza-claro sobre fundo branco. Qual é o principal problema que deve ser investigado?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'O tamanho do banco de dados'),
      (v_q, 2, 'O contraste entre texto e fundo'),
      (v_q, 3, 'A velocidade do processador'),
      (v_q, 4, 'O nome do arquivo HTML')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[2], 'Contraste insuficiente pode dificultar a leitura, especialmente para pessoas com baixa visão, e é uma importante questão de acessibilidade.', 'https://developer.mozilla.org/en-US/docs/Web/Accessibility/Guides/Understanding_WCAG/Perceivable/Color_contrast');

  -- FrontEnd #18
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 18, 'Um elemento possui:

```css
.container {
  display: flex;
  justify-content: center;
}
```

Qual é o efeito principal de `justify-content: center` nesse contexto?', 'hard', 30)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Centralizar os itens ao longo do eixo principal do Flexbox'),
      (v_q, 2, 'Alterar a cor dos itens'),
      (v_q, 3, 'Esconder os itens'),
      (v_q, 4, 'Transformar os itens em imagens')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'justify-content controla a distribuição dos itens no eixo principal do Flexbox. Com center, eles são centralizados nesse eixo.', 'https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/justify-content');

  -- FrontEnd #19
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 19, 'Um usuário consegue navegar pelo site usando o teclado, mas não consegue perceber qual elemento está selecionado. Qual aspecto de acessibilidade está especialmente relacionado ao problema?', 'medium', 20)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Estado de foco visível'),
      (v_q, 2, 'Compressão de imagens'),
      (v_q, 3, 'Tamanho do banco de dados'),
      (v_q, 4, 'Velocidade do servidor')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[1], 'Usuários que navegam pelo teclado precisam conseguir identificar visualmente qual elemento está atualmente em foco.', 'https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Selectors/:focus-visible');

  -- FrontEnd #20
  insert into public.questions (quiz_version_id, sort_order, statement, difficulty, points)
  values (v_ver, 20, 'Você está desenvolvendo um site. Os botões funcionam perfeitamente com o mouse, mas não podem ser acionados pelo teclado. Qual seria a abordagem mais adequada?', 'easy', 10)
  returning id into v_q;
  with o as (
    insert into public.question_options (question_id, sort_order, body) values
      (v_q, 1, 'Remover o botão'),
      (v_q, 2, 'Adicionar mais cores ao botão'),
      (v_q, 3, 'Garantir que a interação também seja acessível pelo teclado'),
      (v_q, 4, 'Aumentar somente o tamanho da fonte')
    returning id, sort_order)
  select array_agg(id order by sort_order) into v_opts from o;
  insert into public.question_solutions (question_id, correct_option_id, explanation, source_url)
  values (v_q, v_opts[3], 'Uma interface acessível deve permitir que suas funcionalidades sejam utilizadas por diferentes formas de interação, incluindo teclado.', 'https://developer.mozilla.org/en-US/docs/Web/Accessibility/Guides/Keyboard-navigable_JavaScript_widgets');

  -- mesmas validações de publish_quiz_version (a RPC exige editor logado)
  if exists (select 1 from public.questions qq
              where qq.quiz_version_id = v_ver
                and ((select count(*) from public.question_options o where o.question_id = qq.id) < 2
                     or not exists (select 1 from public.question_solutions s where s.question_id = qq.id))) then
    raise exception 'Seed FrontEnd: pergunta sem alternativas ou sem gabarito';
  end if;
  update public.quiz_versions set status = 'published', published_at = now() where id = v_ver;
end
$seed$;
